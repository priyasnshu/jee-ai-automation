import { Router } from 'express';
import { requireAuth, requireCsrf } from '../middleware/auth.js';
import { pdfExecutions, processPdf, pdfExecution, updateQuestion, approveQuestion, rejectQuestion, finalizePdfExecution, regenerateQuestionEndpoint, downloadDiagram } from '../controllers/automation.controller.js';

const router = Router();
router.get('/executions', requireAuth, pdfExecutions);
router.post('/process', requireAuth, requireCsrf, processPdf);
router.get('/executions/:id', requireAuth, pdfExecution);
router.patch('/questions/:id', requireAuth, requireCsrf, updateQuestion);
router.post('/questions/:id/approve', requireAuth, requireCsrf, approveQuestion);
router.post('/questions/:id/reject', requireAuth, requireCsrf, rejectQuestion);
router.post('/questions/:id/regenerate', requireAuth, requireCsrf, regenerateQuestionEndpoint);
router.get('/diagrams/:id', requireAuth, downloadDiagram);
router.post('/executions/:id/finalize', requireAuth, requireCsrf, finalizePdfExecution);
export default router;
