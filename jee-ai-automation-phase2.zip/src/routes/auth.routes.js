import { Router } from 'express';
import { login, logout, me } from '../controllers/auth.controller.js';
import { requireAuth, requireCsrf } from '../middleware/auth.js';
import { authRateLimiter } from '../server/rate-limit.js';

const router = Router();
router.post('/login', authRateLimiter, login);
router.post('/logout', requireAuth, requireCsrf, logout);
router.get('/me', requireAuth, me);
export default router;
