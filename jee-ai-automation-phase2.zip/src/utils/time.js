export function isoAfterMs(ms) {
  return new Date(Date.now() + ms).toISOString();
}

export function msFromHours(hours) {
  return Math.max(0, Number(hours) * 60 * 60 * 1000);
}
