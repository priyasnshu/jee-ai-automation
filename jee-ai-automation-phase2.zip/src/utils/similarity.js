function tokens(text) {
  return new Set(String(text ?? '').toLowerCase().match(/[\p{L}\p{N}]+/gu) ?? []);
}

function bigrams(text) {
  const normalized = String(text ?? '').toLowerCase().replace(/\s+/g, ' ').trim();
  const out = new Set();
  for (let i = 0; i < normalized.length - 1; i += 1) out.add(normalized.slice(i, i + 2));
  return out;
}

function jaccard(a, b) {
  if (!a.size && !b.size) return 1;
  let intersection = 0;
  for (const item of a) if (b.has(item)) intersection += 1;
  const union = a.size + b.size - intersection;
  return union ? intersection / union : 0;
}

export function similarityScore(a, b) {
  const tokenScore = jaccard(tokens(a), tokens(b));
  const charScore = jaccard(bigrams(a), bigrams(b));
  return Math.max(0, Math.min(1, tokenScore * 0.6 + charScore * 0.4));
}
