import fs from 'node:fs/promises';
import path from 'node:path';

export async function readMagic(filePath, length = 16) {
  const handle = await fs.open(filePath, 'r');
  try {
    const buffer = Buffer.alloc(length);
    await handle.read(buffer, 0, length, 0);
    return buffer;
  } finally {
    await handle.close();
  }
}

export async function isPdfFile(filePath) {
  const magic = await readMagic(filePath, 8);
  return magic.subarray(0, 5).toString('ascii') === '%PDF-';
}

export async function isImageFile(filePath, mimeType) {
  const magic = await readMagic(filePath, 16);
  if (mimeType === 'image/jpeg') return magic[0] === 0xff && magic[1] === 0xd8 && magic[2] === 0xff;
  if (mimeType === 'image/png') return magic.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10]));
  if (mimeType === 'image/webp') return magic.subarray(0, 4).toString('ascii') === 'RIFF' && magic.subarray(8, 12).toString('ascii') === 'WEBP';
  return false;
}

export function safeRelativePath(relativePath) {
  const normalized = path.posix.normalize(String(relativePath).replaceAll('\\', '/'));
  if (normalized.startsWith('../') || normalized === '..' || normalized.startsWith('/')) throw new Error('Unsafe storage path.');
  return normalized;
}
