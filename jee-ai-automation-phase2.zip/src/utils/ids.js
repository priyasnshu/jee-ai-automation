import crypto from 'node:crypto';

export function internalId(prefix) {
  return `${prefix}_${crypto.randomBytes(10).toString('hex')}`;
}

export function randomToken(bytes = 32) {
  return crypto.randomBytes(bytes).toString('base64url');
}
