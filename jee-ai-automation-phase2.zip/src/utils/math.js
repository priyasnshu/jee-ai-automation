const superscript = Object.freeze({ '0':'⁰','1':'¹','2':'²','3':'³','4':'⁴','5':'⁵','6':'⁶','7':'⁷','8':'⁸','9':'⁹','+':'⁺','-':'⁻','=':'⁼','(':'⁽',')':'⁾','n':'ⁿ','i':'ⁱ' });

function superscriptize(value) {
  return [...String(value)].every(ch => superscript[ch])
    ? [...String(value)].map(ch => superscript[ch]).join('')
    : null;
}

export function normalizeMathText(input) {
  let text = String(input ?? '');
  const original = text;

  const latexSymbols = [
    [/\\theta\b/g, 'θ'], [/\\pi\b/g, 'π'], [/\\mu\b/g, 'μ'], [/\\Omega\b/g, 'Ω'],
    [/\\Delta\b/g, 'Δ'], [/\\leq/g, '≤'], [/\\geq/g, '≥'], [/\\neq/g, '≠'], [/\\approx/g, '≈'],
    [/\\times/g, '×'], [/\\cdot/g, '·']
  ];
  for (const [pattern, replacement] of latexSymbols) text = text.replace(pattern, replacement);

  text = text.replace(/\^\{([A-Za-z0-9+\-=()]+)\}/g, (_, body) => superscriptize(body) ?? `^${body}`);
  text = text.replace(/\^([0-9])/g, (_, digit) => superscript[digit]);
  text = text.replace(/\bsqrt\s*\(\s*([^()]{1,20})\s*\)/gi, '√$1');
  text = text.replace(/<=/g, '≤').replace(/>=/g, '≥').replace(/!=/g, '≠').replace(/~=|=~+/g, '≈');
  text = text.replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim();

  const unsafeLatex = /\\[A-Za-z]+|\{[^}]*$|\^[{\s]/.test(text);
  return { text, changed: text !== original, safe: !unsafeLatex };
}

export function normalizeQuestionText(input) {
  const normalized = normalizeMathText(input);
  return { ...normalized, text: normalized.text.replace(/\s+/g, ' ').trim() };
}

export function normalizeForHash(input) {
  return String(input ?? '')
    .normalize('NFKC')
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .trim()
    .replace(/\s+/g, ' ');
}
