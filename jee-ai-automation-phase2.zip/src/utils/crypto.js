import crypto from 'node:crypto';
import { env } from '../config/env.js';

export function sha256(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

export function hmac(value) {
  return crypto.createHmac('sha256', env.SESSION_SECRET).update(value).digest('hex');
}

export function safeEqualHex(a, b) {
  const left = Buffer.from(a, 'hex');
  const right = Buffer.from(b, 'hex');
  return left.length === right.length && crypto.timingSafeEqual(left, right);
}
