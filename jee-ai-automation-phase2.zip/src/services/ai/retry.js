import { env } from '../../config/env.js';

export function isTransientError(error) {
  const status = Number(error?.status ?? error?.code ?? 0);
  const message = String(error?.message ?? '').toLowerCase();
  return error?.code === 'AI_JSON_PARSE_ERROR' || error?.code === 'AI_RESPONSE_EMPTY' || status === 408 || status === 409 || status === 425 || status === 429 || status >= 500 || /timeout|temporar|rate.?limit|overload|unavailable|econnreset|socket/i.test(message);
}

export async function withRetry(task, { retries = env.MAX_AI_RETRIES, timeoutMs = 60_000, onRetry = () => {} } = {}) {
  let lastError;
  for (let attempt = 0; attempt <= retries; attempt += 1) {
    try {
      let timer;
      const timeout = new Promise((_, reject) => {
        timer = setTimeout(() => reject(Object.assign(new Error(`External call timed out after ${timeoutMs}ms.`), { code: 'ETIMEDOUT' })), timeoutMs);
      });
      try {
        return await Promise.race([task(), timeout]);
      } finally {
        clearTimeout(timer);
      }
    } catch (error) {
      lastError = error;
      if (attempt >= retries || !isTransientError(error)) throw error;
      const delay = Math.min(10_000, 750 * (2 ** attempt));
      onRetry({ attempt: attempt + 1, delay, error });
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
  throw lastError;
}
