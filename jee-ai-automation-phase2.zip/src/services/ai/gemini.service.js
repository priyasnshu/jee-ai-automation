import { GoogleGenAI } from '@google/genai';
import { env } from '../../config/env.js';
import { logger } from '../logger.js';
import { withRetry } from './retry.js';

let client;

function getClient() {
  if (!env.GEMINI_API_KEY) throw new Error('GEMINI_API_KEY is not configured.');
  client ??= new GoogleGenAI({ apiKey: env.GEMINI_API_KEY, httpOptions: { timeout: 60_000 } });
  return client;
}

export async function geminiStructuredJson({ prompt, responseSchema, model = env.GEMINI_MODEL }) {
  if (!model) throw new Error('GEMINI_MODEL is not configured.');
  const ai = getClient();
  return withRetry(
    async () => {
      const response = await ai.models.generateContent({
        model,
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema
        }
      });
      const text = response.text?.trim();
      if (!text) throw Object.assign(new Error('Gemini returned an empty response.'), { code:'AI_RESPONSE_EMPTY' });
      try {
        return JSON.parse(text);
      } catch (error) {
        throw Object.assign(new Error('Gemini returned malformed JSON.'), { code:'AI_JSON_PARSE_ERROR', cause:error });
      }
    },
    { onRetry: ({ attempt, delay, error }) => logger.warn({ attempt, delay, err:error }, 'Retrying Gemini structured-output request') }
  );
}

export async function checkGemini() {
  if (env.MOCK_EXTERNAL_SERVICES) return { status: 'mock', configured: true };
  if (!env.GEMINI_API_KEY || !env.GEMINI_MODEL) return { status: 'not_configured', configured: false };
  try {
    return { status: 'configured', configured: true };
  } catch (error) {
    logger.warn({ err: error }, 'Gemini configuration check failed');
    return { status: 'error', configured: false };
  }
}
