const keywordMap = [
  { branch: 'pdf_questions', words: ['pdf', 'extract questions', 'extract all questions', 'question bank', 'questions from these files', 'questions from these pdfs'] },
  { branch: 'jee_news', words: ['latest jee', 'jee update', 'jee news', 'nta update', 'jee main update', 'jee advanced update', 'notification', 'admit card', 'answer key', 'result', 'exam date'] },
  { branch: 'polls', words: ['poll', 'polls', 'quiz', 'telegram poll'] },
  { branch: 'formula_sheet', words: ['formula sheet', 'formula', 'formulae', 'revision sheet'] },
  { branch: 'notes', words: ['notes', 'handwritten', 'photo notes', 'make notes', 'clean these notes'] }
];

export function mockRouteDecision(input) {
  const text = `${input.instruction} ${input.topic || ''} ${input.chapter || ''}`.toLowerCase();
  const inputType = input.fileIds?.length ? 'mixed' : 'text';
  let best = { branch: 'notes', score: 0 };
  for (const item of keywordMap) {
    const score = item.words.reduce((acc, word) => acc + (text.includes(word) ? 1 : 0), 0);
    if (score > best.score) best = { branch: item.branch, score };
  }
  if (input.fileIds?.length && /question|extract|pdf/.test(text)) best = { branch: 'pdf_questions', score: best.score + 1 };
  if (input.fileIds?.length && /poll/.test(text)) best = { branch: 'polls', score: best.score + 1 };

  return {
    branch: best.branch,
    confidence: best.score >= 2 ? 0.98 : best.score === 1 ? 0.78 : 0.55,
    topic: input.topic || null,
    chapter: input.chapter || null,
    input_type: inputType,
    requested_count: input.requestedCount ?? null,
    publish_to_telegram: input.publishToTelegram ?? /telegram|publish|send/.test(text),
    create_google_doc: input.createGoogleDoc ?? /google doc|google docs|document/.test(text),
    schedule: null,
    priority: 'normal'
  };
}
