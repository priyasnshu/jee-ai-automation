import fs from 'node:fs/promises';
import path from 'node:path';
import { RouterOutputSchema } from '../../validators/router.js';
import { env } from '../../config/env.js';
import { geminiStructuredJson } from './gemini.service.js';
import { logger } from '../logger.js';

const schema = {
  type: 'object',
  properties: {
    branch: { type: 'string', enum: ['pdf_questions','jee_news','polls','formula_sheet','notes'] },
    confidence: { type: 'number', description: '0 to 1 confidence in the branch classification' },
    topic: { type: ['string','null'] },
    chapter: { type: ['string','null'] },
    input_type: { type: 'string', enum: ['text','pdf','image','mixed'] },
    requested_count: { type: ['integer','null'] },
    publish_to_telegram: { type: 'boolean' },
    create_google_doc: { type: 'boolean' },
    schedule: { type: ['string','null'] },
    priority: { type: 'string', enum: ['low','normal','high'] }
  },
  required: ['branch','confidence','topic','chapter','input_type','requested_count','publish_to_telegram','create_google_doc','schedule','priority']
};

import { mockRouteDecision } from './router.logic.js';

async function loadPrompt() {
  return fs.readFile(path.resolve(process.cwd(), 'src/prompts/router.txt'), 'utf8');
}

export async function routeInstruction(input, inputMetadata = []) {
  if (input.branch && input.branch !== 'auto') {
    return RouterOutputSchema.parse({
      branch: input.branch,
      confidence: 1,
      topic: input.topic || null,
      chapter: input.chapter || null,
      input_type: inputMetadata.some(f => f.kind === 'pdf') && inputMetadata.some(f => f.kind === 'image') ? 'mixed' : inputMetadata[0]?.kind || 'text',
      requested_count: input.requestedCount ?? null,
      publish_to_telegram: input.publishToTelegram ?? false,
      create_google_doc: input.createGoogleDoc ?? false,
      schedule: null,
      priority: 'normal'
    });
  }

  if (env.MOCK_EXTERNAL_SERVICES) return RouterOutputSchema.parse(mockRouteDecision(input));

  const promptTemplate = await loadPrompt();
  const prompt = promptTemplate
    .replace('{{USER_INSTRUCTION}}', input.instruction)
    .replace('{{INPUT_METADATA}}', JSON.stringify(inputMetadata.map(({ id, originalName, kind, mimeType, sizeBytes }) => ({ id, originalName, kind, mimeType, sizeBytes }))));

  const raw = await geminiStructuredJson({ prompt, responseSchema: schema });
  const parsed = RouterOutputSchema.safeParse(raw);
  if (!parsed.success) {
    logger.error({ issues: parsed.error.issues }, 'AI Router schema validation failed');
    throw new Error('AI Router returned invalid structured output.');
  }
  return parsed.data;
}
