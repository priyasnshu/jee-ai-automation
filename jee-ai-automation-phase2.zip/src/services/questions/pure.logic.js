import { normalizeForHash } from '../../utils/math.js';

export function reconcileCandidateSets(pass1, pass2) {
  const merged = [...pass1];
  const normalizedExisting = new Set(merged.map(q => normalizeForHash(q.question_text)));
  for (const q of pass2) {
    const key = normalizeForHash(q.question_text);
    if (!normalizedExisting.has(key)) {
      merged.push({ ...q, issues: [...(q.issues ?? []), 'Added by independent pass 2.'] });
      normalizedExisting.add(key);
    }
  }
  merged.sort((a, b) => (a.page_start - b.page_start) || String(a.external_number ?? '').localeCompare(String(b.external_number ?? '')));
  return { questions: merged, decisions: merged.map((q, index) => ({ action: pass1.some(p => normalizeForHash(p.question_text) === normalizeForHash(q.question_text)) ? 'kept' : 'added', reason: 'Independent extraction reconciliation.', source_candidate_ids: [`p2-${index}`] })) };
}

export function uniqueCanonicalQuestions(canonical) {
  const out = [];
  for (const candidate of canonical) {
    const normalized = normalizeForHash(candidate.question_text);
    const existing = out.find(item => normalizeForHash(item.question_text) === normalized);
    if (!existing) out.push({ ...candidate });
    else {
      existing.page_start = Math.min(existing.page_start, candidate.page_start);
      existing.page_end = Math.max(existing.page_end, candidate.page_end);
      existing.options = existing.options.length >= candidate.options.length ? existing.options : candidate.options;
      existing.issues = [...new Set([...(existing.issues ?? []), ...(candidate.issues ?? [])])];
    }
  }
  return out;
}

export function heuristicQuestionAudit(question) {
  const issues = [];
  if (question.question_text.length < 8) issues.push('Question text is unusually short.');
  if (/\b(?:option|answer)\s*[A-D]\b/i.test(question.question_text) && question.options.length < 2) issues.push('Question appears to reference answer choices, but options are incomplete.');
  if (question.options.length === 1) issues.push('Only one option was extracted.');
  if (!question.external_number) issues.push('Question number could not be confirmed.');
  if (!question.confidence || question.confidence < 0.65) issues.push('Extraction confidence is low.');
  return { status: issues.length ? 'needs_review' : 'verified', issues, confidence: issues.length ? Math.max(0.55, question.confidence ?? 0.55) : Math.min(0.99, (question.confidence ?? 0.8) + 0.08) };
}

export function detectDiagramTypeHeuristic(text) {
  const patterns = [
    ['inclined_plane', /inclined|incline|slope|block.*plane/i], ['pulley', /pulley|string.*mass/i], ['circuit', /circuit|resistor|battery|current.*wire/i],
    ['ray_optics', /ray.*optics|refract|refraction/i], ['lens', /lens|convex lens|concave lens/i], ['mirror', /mirror|reflect/i], ['geometry', /triangle|circle|angle|geometry/i],
    ['vector', /vector|components|resultant/i], ['projectile', /projectile|range|trajectory/i], ['graph', /graph|plot|curve/i], ['coordinate_system', /coordinate|x-axis|y-axis/i],
    ['electric_field', /electric field|field lines|charge/i], ['thermodynamics', /thermodynamic|piston|gas.*container/i]
  ];
  return patterns.find(([, regex]) => regex.test(text))?.[0] ?? 'other';
}
