import { z } from 'zod';

export const QuestionCandidateSchema = z.object({
  external_number: z.string().trim().max(80).nullable().default(null),
  page_start: z.number().int().positive(),
  page_end: z.number().int().positive(),
  question_text: z.string().trim().min(3).max(20000),
  options: z.array(z.string().trim().min(1).max(2000)).max(8).default([]),
  answer: z.string().trim().max(2000).nullable().default(null),
  needs_diagram_hint: z.boolean().default(false),
  confidence: z.number().min(0).max(1).default(0.7),
  issues: z.array(z.string().trim().min(1).max(500)).max(20).default([])
}).strict().superRefine((value, ctx) => {
  if (value.page_end < value.page_start) ctx.addIssue({ code: 'custom', path: ['page_end'], message: 'page_end must be >= page_start' });
  if (value.options.length === 1) ctx.addIssue({ code: 'custom', path: ['options'], message: 'A single option is not a valid MCQ option set.' });
  const deduped = new Set(value.options.map(option => option.toLowerCase()));
  if (deduped.size !== value.options.length) ctx.addIssue({ code: 'custom', path: ['options'], message: 'Duplicate options detected.' });
});

export const ExtractionResponseSchema = z.object({
  questions: z.array(QuestionCandidateSchema).max(1000)
}).strict();

export const ReconciliationResponseSchema = z.object({
  questions: z.array(QuestionCandidateSchema).max(1000),
  decisions: z.array(z.object({
    action: z.enum(['kept','merged','added','rejected']),
    reason: z.string().trim().min(1).max(1000),
    source_candidate_ids: z.array(z.string()).max(20)
  })).max(1000)
}).strict();

export const DiagramDetectionSchema = z.object({
  results: z.array(z.object({
    question_index: z.number().int().nonnegative(),
    needs_diagram: z.boolean(),
    diagram_type: z.enum(['inclined_plane','pulley','circuit','ray_optics','lens','mirror','geometry','vector','projectile','graph','coordinate_system','electric_field','thermodynamics','other']).nullable(),
    reason: z.string().trim().max(1000),
    required_labels: z.array(z.string().trim().min(1).max(100)).max(30)
  })).max(1000)
}).strict();

export const QuestionAuditSchema = z.object({
  results: z.array(z.object({
    question_index: z.number().int().nonnegative(),
    status: z.enum(['verified','needs_review','rejected']),
    issues: z.array(z.string().trim().min(1).max(500)).max(20),
    confidence: z.number().min(0).max(1)
  })).max(1000)
}).strict();

export const DuplicateAdjudicationSchema = z.object({
  results: z.array(z.object({
    pair_index: z.number().int().nonnegative(),
    duplicate: z.boolean(),
    confidence: z.number().min(0).max(1),
    reason: z.string().trim().min(1).max(1000)
  })).max(200)
}).strict();
