import crypto from 'node:crypto';
import { getDb } from '../../database/index.js';
import { internalId } from '../../utils/ids.js';
import { json, safeJsonParse } from '../../utils/json.js';
import { normalizeQuestionText, normalizeForHash } from '../../utils/math.js';
import { reconcileCandidateSets, uniqueCanonicalQuestions, heuristicQuestionAudit, detectDiagramTypeHeuristic } from './pure.logic.js';
import { similarityScore } from '../../utils/similarity.js';
import { env } from '../../config/env.js';
import { geminiStructuredJson } from '../ai/gemini.service.js';
import { ExtractionResponseSchema, QuestionCandidateSchema, ReconciliationResponseSchema, DuplicateAdjudicationSchema, QuestionAuditSchema, DiagramDetectionSchema } from './schemas.js';
import fs from 'node:fs/promises';
import path from 'node:path';

const MODEL_LIMIT_CHARS = env.MAX_PDF_BATCH_CHARS || 45_000;
const STOPWORDS = new Set(['the','a','an','is','are','of','to','and','in','for','on','by','with','from','find','calculate','determine','what','which','the']);

function schemaToGemini(schema) {
  return schema;
}

function loadPrompt(name) {
  return fs.readFile(path.resolve(process.cwd(), 'src/prompts', name), 'utf8');
}

export function pageBatches(pages, maxChars = MODEL_LIMIT_CHARS) {
  const batches = [];
  let current = [];
  let chars = 0;
  for (const page of pages) {
    const pageChars = page.text.length;
    if (current.length && chars + pageChars > maxChars) {
      batches.push(current);
      const overlap = current.at(-1);
      current = overlap ? [overlap] : [];
      chars = overlap?.text.length ?? 0;
    }
    current.push(page);
    chars += pageChars;
  }
  if (current.length) batches.push(current);
  return batches;
}

function pagesAsSource(pages) {
  return pages.map(page => `\n=== PAGE ${page.pageNumber} ===\n<UNTRUSTED_PDF_TEXT>\n${page.text}\n</UNTRUSTED_PDF_TEXT>`).join('\n');
}

function validCandidate(raw, pageCount) {
  const parsed = QuestionCandidateSchema.safeParse(raw);
  if (!parsed.success) return null;
  const value = parsed.data;
  if (value.page_start > pageCount || value.page_end > pageCount) return null;
  if (value.page_end < value.page_start) return null;
  const normalized = normalizeQuestionText(value.question_text);
  if (!normalized.safe || normalized.text.length < 3) {
    return { ...value, question_text: normalized.text, issues: [...value.issues, 'Mathematical notation could not be safely normalized.'] };
  }
  return { ...value, question_text: normalized.text };
}

function mockExtractQuestions(pages) {
  const results = [];
  const marker = /(?:^|\s)(?:Q(?:uestion)?\.?\s*)?(\d{1,3})[.)-]\s+(.+?)(?=(?:\s+Q(?:uestion)?\.?\s*\d{1,3}[.)-]\s+)|$)/gis;
  let lastQuestion = null;
  for (const page of pages) {
    const text = page.text.replace(/\n+/g, ' ').replace(/\s+/g, ' ').trim();
    let found = false;
    let match;
    while ((match = marker.exec(text)) !== null) {
      found = true;
      const q = match[2].trim();
      const options = [...q.matchAll(/(?:^|\s)([A-D])[.)]\s*([^\n]+)/g)].map(m => `${m[1]}) ${m[2].trim()}`).slice(0, 4);
      const cleaned = q.replace(/\s+[A-D][.)]\s+[^\n]+$/i, '').trim();
      const item = { external_number: match[1], page_start: page.pageNumber, page_end: page.pageNumber, question_text: cleaned, options, answer: null, needs_diagram_hint: /diagram|figure|inclined|pulley|circuit|ray|lens|mirror|graph|vector/i.test(cleaned), confidence: 0.9, issues: [] };
      results.push(item);
      lastQuestion = item;
    }
    if (!found && lastQuestion && text.length > 10) {
      lastQuestion.question_text = `${lastQuestion.question_text} ${text}`.trim();
      lastQuestion.page_end = page.pageNumber;
      lastQuestion.issues = [...lastQuestion.issues, 'Question continued onto the next page.'];
      continue;
    }
    if (!found && !lastQuestion && text.length > 30 && /\b(question|calculate|find|determine|which)\b/i.test(text)) {
      const item = { external_number: null, page_start: page.pageNumber, page_end: page.pageNumber, question_text: text, options: [], answer: null, needs_diagram_hint: /diagram|figure|inclined|pulley|circuit|ray|lens|mirror|graph|vector/i.test(text), confidence: 0.55, issues: ['Question number was not detected deterministically.'] };
      results.push(item);
      lastQuestion = item;
    }
  }
  return results;
}

export async function extractPass(pages, passNumber, fileName) {
  if (env.MOCK_EXTERNAL_SERVICES) return mockExtractQuestions(pages).map(item => ({ ...item, issues: [...item.issues, `mock_pass_${passNumber}`] }));
  const prompt = await loadPrompt(passNumber === 1 ? 'pdf-extraction.txt' : 'question-review.txt');
  const responseSchema = {
    type: 'object',
    properties: {
      questions: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            external_number: { type: ['string','null'] }, page_start: { type: 'integer' }, page_end: { type: 'integer' },
            question_text: { type: 'string' }, options: { type: 'array', items: { type: 'string' } }, answer: { type: ['string','null'] },
            needs_diagram_hint: { type: 'boolean' }, confidence: { type: 'number' }, issues: { type: 'array', items: { type: 'string' } }
          },
          required: ['external_number','page_start','page_end','question_text','options','answer','needs_diagram_hint','confidence','issues']
        }
      }
    },
    required: ['questions']
  };
  const result = await geminiStructuredJson({
    prompt: `${prompt}\n\nSOURCE FILE: ${fileName}\nPASS NUMBER: ${passNumber}\n\n${pagesAsSource(pages)}`,
    responseSchema
  });
  const parsed = ExtractionResponseSchema.safeParse(result);
  if (!parsed.success) throw new Error(`PASS_${passNumber}_SCHEMA_INVALID`);
  return parsed.data.questions.map(item => validCandidate(item, pages.at(-1)?.pageNumber ?? 1)).filter(Boolean);
}

export async function reconcileChunk(pages, pass1, pass2, fileName) {
  if (env.MOCK_EXTERNAL_SERVICES) return reconcileCandidateSets(pass1, pass2);
  const prompt = await loadPrompt('question-reconciliation.txt');
  const responseSchema = {
    type: 'object',
    properties: {
      questions: { type: 'array', items: {
        type: 'object', properties: {
          external_number:{type:['string','null']}, page_start:{type:'integer'}, page_end:{type:'integer'}, question_text:{type:'string'}, options:{type:'array',items:{type:'string'}}, answer:{type:['string','null']}, needs_diagram_hint:{type:'boolean'}, confidence:{type:'number'}, issues:{type:'array',items:{type:'string'}}
        }, required:['external_number','page_start','page_end','question_text','options','answer','needs_diagram_hint','confidence','issues']
      }},
      decisions: { type: 'array', items: { type: 'object', properties: { action:{type:'string',enum:['kept','merged','added','rejected']},reason:{type:'string'},source_candidate_ids:{type:'array',items:{type:'string'}} }, required:['action','reason','source_candidate_ids'] } }
    }, required:['questions','decisions']
  };
  const result = await geminiStructuredJson({
    prompt: `${prompt}\n\nSOURCE FILE: ${fileName}\n\nSOURCE PAGES:\n${pagesAsSource(pages)}\n\nPASS 1 CANDIDATES:\n${JSON.stringify(pass1)}\n\nPASS 2 CANDIDATES:\n${JSON.stringify(pass2)}`,
    responseSchema
  });
  const parsed = ReconciliationResponseSchema.safeParse(result);
  if (!parsed.success) throw new Error('RECONCILIATION_SCHEMA_INVALID');
  return { questions: parsed.data.questions.map(q => validCandidate(q, pages.at(-1)?.pageNumber ?? 1)).filter(Boolean), decisions: parsed.data.decisions };
}

async function auditChunk(questions) {
  if (!questions.length) return [];
  if (env.MOCK_EXTERNAL_SERVICES) return questions.map(heuristicQuestionAudit);
  const prompt = await loadPrompt('question-quality-audit.txt');
  const responseSchema = { type:'object', properties:{ results:{type:'array',items:{type:'object',properties:{question_index:{type:'integer'},status:{type:'string',enum:['verified','needs_review','rejected']},issues:{type:'array',items:{type:'string'}},confidence:{type:'number'}},required:['question_index','status','issues','confidence']}}},required:['results'] };
  const result = await geminiStructuredJson({ prompt: `${prompt}\n\nQUESTIONS:\n${JSON.stringify(questions)}`, responseSchema });
  const parsed = QuestionAuditSchema.safeParse(result);
  if (!parsed.success) throw new Error('QUALITY_AUDIT_SCHEMA_INVALID');
  return questions.map((_q, index) => parsed.data.results.find(r => r.question_index === index) ?? { status:'needs_review', issues:['No audit result returned.'], confidence:0 });
}

async function detectDiagramChunk(questions) {
  if (!questions.length) return [];
  if (env.MOCK_EXTERNAL_SERVICES) {
    return questions.map((q, index) => ({ question_index:index, needs_diagram: q.needs_diagram_hint, diagram_type: q.needs_diagram_hint ? detectDiagramTypeHeuristic(q.question_text) : null, reason:q.needs_diagram_hint ? 'Deterministic mock rule matched a diagram-dependent topic.' : 'No diagram dependency detected.', required_labels:[] }));
  }
  const prompt = await loadPrompt('diagram-detection.txt');
  const responseSchema = { type:'object', properties:{results:{type:'array',items:{type:'object',properties:{question_index:{type:'integer'},needs_diagram:{type:'boolean'},diagram_type:{type:['string','null']},reason:{type:'string'},required_labels:{type:'array',items:{type:'string'}}},required:['question_index','needs_diagram','diagram_type','reason','required_labels']}}},required:['results'] };
  const result = await geminiStructuredJson({ prompt:`${prompt}\n\nQUESTIONS:\n${JSON.stringify(questions.map(({question_text,options},index)=>({question_index:index,question_text,options})))}`, responseSchema });
  const parsed = DiagramDetectionSchema.safeParse(result);
  if (!parsed.success) throw new Error('DIAGRAM_DETECTION_SCHEMA_INVALID');
  return questions.map((_q,index)=>parsed.data.results.find(r=>r.question_index===index) ?? {question_index:index,needs_diagram:false,diagram_type:null,reason:'No result returned.',required_labels:[]});
}

async function adjudicateDuplicates(pairs) {
  if (!pairs.length || env.MOCK_EXTERNAL_SERVICES) return pairs.map(pair => ({ ...pair, duplicate: pair.similarity >= 0.86, confidence: pair.similarity, reason:'Heuristic duplicate adjudication in mock mode.' }));
  const prompt = await loadPrompt('duplicate-adjudication.txt');
  const responseSchema = { type:'object', properties:{results:{type:'array',items:{type:'object',properties:{pair_index:{type:'integer'},duplicate:{type:'boolean'},confidence:{type:'number'},reason:{type:'string'}},required:['pair_index','duplicate','confidence','reason']}}},required:['results'] };
  const result = await geminiStructuredJson({ prompt:`${prompt}\n\nPAIRS:\n${JSON.stringify(pairs.map((pair,index)=>({pair_index:index,a:pair.questionA,b:pair.questionB})))}`, responseSchema });
  const parsed = DuplicateAdjudicationSchema.safeParse(result);
  if (!parsed.success) throw new Error('DUPLICATE_ADJUDICATION_SCHEMA_INVALID');
  return pairs.map((pair,index)=>({ ...pair, ...(parsed.data.results.find(r=>r.pair_index===index) ?? {duplicate:false,confidence:0,reason:'No adjudication result returned.'}) }));
}

export async function persistPdfPages({ executionId, fileId, pages }) {
  const db = getDb();
  const insert = db.prepare(`INSERT OR REPLACE INTO pdf_pages (id,file_id,execution_id,page_number,text_content,character_count,extraction_status,extraction_error) VALUES (?,?,?,?,?,?,?,?)`);
  const tx = db.transaction(items => items.forEach(page => insert.run(internalId('page'), fileId, executionId, page.pageNumber, page.text, page.text.length, page.extractionStatus, page.extractionError ?? null)));
  tx(pages);
}

export async function extractAndPersistFile({ executionId, file }) {
  const { extractPdfPages } = await import('./extractor.js');
  const extracted = await extractPdfPages({ filePath:file.absolute_path, relativePath:file.relative_path });
  const db = getDb();
  persistPdfPages({ executionId, fileId:file.id, pages:extracted.pages });
  const emptyPages = extracted.pages.filter(page => page.extractionStatus === 'empty').length;
  db.prepare(`UPDATE uploaded_files SET execution_id=?, page_count=?, extraction_status=?, extraction_error=? WHERE id=?`)
    .run(executionId, extracted.pageCount, emptyPages === extracted.pageCount ? 'ocr_required' : emptyPages ? 'partial' : 'extracted', emptyPages ? `${emptyPages} page(s) returned no extractable text.` : null, file.id);
  return extracted;
}

export async function runExtractionPasses({ executionId, file, pages }) {
  const batches = pageBatches(pages.filter(p => p.text.trim()), MODEL_LIMIT_CHARS);
  const db = getDb();
  const allPass1 = [];
  const allPass2 = [];
  const allCanonical = [];
  for (let i=0;i<batches.length;i+=1) {
    const batch = batches[i];
    const batchKey = `batch-${i+1}`;
    const pass1 = await extractPass(batch,1,file.original_name);
    const pass2 = await extractPass(batch,2,file.original_name);
    const reconciliation = await reconcileChunk(batch,pass1,pass2,file.original_name);
    for (const [passNumber, items] of [[1,pass1],[2,pass2]]) {
      const insert = db.prepare(`INSERT INTO question_candidates (id,execution_id,file_id,pass_number,batch_key,external_number,page_start,page_end,question_text,options_json,answer,needs_diagram_hint,issues_json,confidence,source_model) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
      for (const q of items) insert.run(internalId('cand'),executionId,file.id,passNumber,batchKey,q.external_number,q.page_start,q.page_end,q.question_text,json(q.options),q.answer,q.needs_diagram_hint?1:0,json(q.issues),q.confidence,env.MOCK_EXTERNAL_SERVICES?'mock':env.GEMINI_MODEL || null);
    }
    allPass1.push(...pass1);
    allPass2.push(...pass2);
    for (const q of reconciliation.questions) allCanonical.push({ ...q, fileId:file.id, fileName:file.original_name, batchKey });
    const decisionInsert = db.prepare(`INSERT INTO execution_events (execution_id,event_type,payload_json) VALUES (?,?,?)`);
    decisionInsert.run(executionId,'pdf.reconciliation_batch',json({batchKey,pass1Count:pass1.length,pass2Count:pass2.length,canonicalCount:reconciliation.questions.length,decisions:reconciliation.decisions}));
  }
  return { pass1:allPass1, pass2:allPass2, canonical:allCanonical };
}

export async function persistCanonicalQuestions({ executionId, questions, topic, chapter, requestedCount = null }) {
  const db = getDb();
  const insert = db.prepare(`INSERT INTO questions (id,execution_id,source_file_id,question_number,source_page,source_page_start,source_page_end,source_reference,chapter,topic,question_text,raw_text,options_json,answer,normalized_hash,confidence,needs_diagram,diagram_type,diagram_reason,required_labels_json,status,reconciliation_json) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  const persisted = [];
  const limit = Math.min(env.MAX_QUESTIONS, requestedCount ?? env.MAX_QUESTIONS);
  const canonical = uniqueCanonicalQuestions(questions).slice(0, limit);
  const tx = db.transaction(items => items.forEach((q,index) => {
    const id = internalId('question');
    const normalized = normalizeForHash(q.question_text);
    insert.run(id,executionId,q.fileId,q.external_number,q.page_start,q.page_start,q.page_end,`${q.fileName ?? q.fileId} pages ${q.page_start}-${q.page_end}`,chapter || null,topic || null,q.question_text,q.question_text,json(q.options),q.answer,crypto.createHash('sha256').update(normalized).digest('hex'),q.confidence,q.needs_diagram_hint?1:0,null,null,null,'needs_review',json({batchKey:q.batchKey}));
    db.prepare(`INSERT INTO question_versions (id,question_id,version_number,question_text,options_json,answer,change_type,created_by) VALUES (?,?,?,?,?,?,?,?)`).run(internalId('qv'),id,1,q.question_text,json(q.options),q.answer,'extraction','system');
    persisted.push({ id, ...q, normalizedHash: normalized });
  }));
  tx(canonical);
  return persisted;
}

export function detectDuplicates(executionId) {
  const db = getDb();
  const questions = db.prepare('SELECT * FROM questions WHERE execution_id = ? ORDER BY created_at ASC').all(executionId);
  const pairs = [];
  for (let i=0;i<questions.length;i+=1) {
    for (let j=i+1;j<questions.length;j+=1) {
      if (questions[i].normalized_hash && questions[i].normalized_hash === questions[j].normalized_hash) {
        pairs.push({questionA:questions[i].question_text,questionB:questions[j].question_text,questionAId:questions[i].id,questionBId:questions[j].id,similarity:1,method:'normalized_hash'});
        continue;
      }
      const score = similarityScore(questions[i].question_text, questions[j].question_text);
      if (score >= 0.72) pairs.push({questionA:questions[i].question_text,questionB:questions[j].question_text,questionAId:questions[i].id,questionBId:questions[j].id,similarity:score,method:'token_char_similarity'});
    }
  }
  return pairs;
}

export async function persistDuplicateCandidates(executionId, pairs) {
  if (!pairs.length) return [];
  const adjudicated = await adjudicateDuplicates(pairs.slice(0,100));
  const db = getDb();
  const insert = db.prepare(`INSERT OR IGNORE INTO question_duplicates (id,execution_id,question_a_id,question_b_id,similarity,method,status) VALUES (?,?,?,?,?,?,?)`);
  const out=[];
  for (const pair of adjudicated) {
    if (!pair.duplicate) continue;
    insert.run(internalId('dup'),executionId,pair.questionAId,pair.questionBId,pair.similarity,pair.method,pair.similarity>=0.98?'confirmed':'candidate');
    db.prepare("UPDATE questions SET duplicate_candidate=1, status=CASE WHEN status='rejected' THEN status ELSE 'needs_review' END, updated_at=CURRENT_TIMESTAMP WHERE id IN (?,?)").run(pair.questionAId,pair.questionBId);
    out.push(pair);
  }
  return out;
}

export async function regenerateQuestion({ questionId, userId }) {
  const db = getDb();
  const question = db.prepare(`SELECT q.*, e.user_id, f.original_name, f.id file_id, f.execution_id file_execution_id
    FROM questions q JOIN executions e ON e.id=q.execution_id JOIN uploaded_files f ON f.id=q.source_file_id
    WHERE q.id=? AND e.user_id=?`).get(questionId, userId);
  if (!question) throw new Error('QUESTION_NOT_FOUND');
  const pages = db.prepare(`SELECT * FROM pdf_pages WHERE file_id=? AND page_number BETWEEN ? AND ? ORDER BY page_number`).all(question.file_id, question.source_page_start, question.source_page_end);
  if (!pages.length) throw new Error('SOURCE_PAGES_NOT_FOUND');

  let candidate;
  if (env.MOCK_EXTERNAL_SERVICES) {
    candidate = { question_text: normalizeQuestionText(question.question_text).text, options: safeJsonParse(question.options_json, []), answer: question.answer, page_start: question.source_page_start, page_end: question.source_page_end, external_number: question.question_number };
  } else {
    const prompt = await loadPrompt('question-regeneration.txt');
    const responseSchema = { type:'object', properties:{question:{type:'object',properties:{external_number:{type:['string','null']},page_start:{type:'integer'},page_end:{type:'integer'},question_text:{type:'string'},options:{type:'array',items:{type:'string'}},answer:{type:['string','null']},needs_diagram_hint:{type:'boolean'},confidence:{type:'number'},issues:{type:'array',items:{type:'string'}}},required:['external_number','page_start','page_end','question_text','options','answer','needs_diagram_hint','confidence','issues']}},required:['question'] };
    const result=await geminiStructuredJson({prompt:`${prompt}\n\nSOURCE PAGES:\n${pagesAsSource(pages)}\n\nCURRENT EXTRACTION:\n${JSON.stringify({question_text:question.question_text,options:safeJsonParse(question.options_json,[]),source_page_start:question.source_page_start,source_page_end:question.source_page_end})}`,responseSchema});
    const parsed=ExtractionResponseSchema.shape ? QuestionCandidateSchema.safeParse(result.question) : null;
    if(!parsed?.success) throw new Error('REGENERATION_SCHEMA_INVALID');
    candidate=parsed.data;
  }
  const normalized=normalizeQuestionText(candidate.question_text);
  if(!normalized.safe) throw new Error('REGENERATION_MATH_UNSAFE');
  const nextVersion=db.prepare('SELECT COALESCE(MAX(version_number),0)+1 next FROM question_versions WHERE question_id=?').get(questionId).next;
  db.prepare('UPDATE questions SET question_text=?, raw_text=?, options_json=?, answer=?, confidence=?, status=\'needs_review\', updated_at=CURRENT_TIMESTAMP WHERE id=?').run(normalized.text,normalized.text,json(candidate.options),candidate.answer??null,candidate.confidence??question.confidence,questionId);
  db.prepare(`INSERT INTO question_versions (id,question_id,version_number,question_text,options_json,answer,change_type,created_by) VALUES (?,?,?,?,?,?,?,?)`).run(internalId('qv'),questionId,nextVersion,normalized.text,json(candidate.options),candidate.answer??null,'ai_regeneration','ai');
  db.prepare(`INSERT INTO question_reviews (id,question_id,reviewer_type,version,status,issues_json,source) VALUES (?,?,?,?,?,?,?)`).run(internalId('review'),questionId,'ai',nextVersion,'needs_review',json(candidate.issues ?? []),'regeneration');
  return {questionId,version:nextVersion,status:'needs_review'};
}

export async function qualityAudit(executionId) {
  const db = getDb();
  const questions = db.prepare('SELECT * FROM questions WHERE execution_id = ? ORDER BY rowid ASC').all(executionId);
  const chunkSize = 20;
  const auditResults=[];
  for (let i=0;i<questions.length;i+=chunkSize) {
    const chunk=questions.slice(i,i+chunkSize);
    const results=await auditChunk(chunk.map(q=>({question_text:q.question_text,options:safeJsonParse(q.options_json,[]),confidence:q.confidence,external_number:q.question_number})));
    chunk.forEach((q,index)=>{
      const result=results[index];
      const finalStatus = q.duplicate_candidate ? 'needs_review' : result.status;
      const finalIssues = q.duplicate_candidate ? [...new Set([...(result.issues ?? []), 'Duplicate candidate requires manual review.'])] : result.issues;
      db.prepare('UPDATE questions SET status=?, confidence=?, updated_at=CURRENT_TIMESTAMP WHERE id=?').run(finalStatus,result.confidence,q.id);
      db.prepare(`INSERT INTO question_reviews (id,question_id,reviewer_type,version,status,issues_json,source) VALUES (?,?,?,?,?,?,?)`).run(internalId('review'),q.id,'ai',1,result.status,json(finalIssues),'quality_audit');
      auditResults.push({questionId:q.id,status:finalStatus,issues:finalIssues,confidence:result.confidence});
    });
  }
  return auditResults;
}

export async function detectDiagrams(executionId) {
  const db=getDb();
  const questions=db.prepare('SELECT * FROM questions WHERE execution_id=? ORDER BY rowid ASC').all(executionId);
  const chunkSize=20;
  const results=[];
  for(let i=0;i<questions.length;i+=chunkSize){
    const chunk=questions.slice(i,i+chunkSize);
    const detections=await detectDiagramChunk(chunk.map(q=>({question_text:q.question_text,options:safeJsonParse(q.options_json,[]),needs_diagram_hint:Boolean(q.needs_diagram)})));
    chunk.forEach((q,index)=>{
      const d=detections[index];
      db.prepare('UPDATE questions SET needs_diagram=?, updated_at=CURRENT_TIMESTAMP WHERE id=?').run(d.needs_diagram?1:0,q.id);
      results.push({questionId:q.id,...d});
    });
  }
  return results;
}
