import bcrypt from 'bcryptjs';
import { getDb } from '../database/index.js';
import { env } from '../config/env.js';
import { hmac, safeEqualHex } from '../utils/crypto.js';
import { internalId, randomToken } from '../utils/ids.js';
import { isoAfterMs, msFromHours } from '../utils/time.js';

export async function authenticateUser(email, password) {
  const user = getDb().prepare('SELECT * FROM users WHERE lower(email) = lower(?)').get(email);
  if (!user) return null;
  const ok = await bcrypt.compare(password, user.password_hash);
  return ok ? user : null;
}

export function createSession(userId, rememberMe = false) {
  const db = getDb();
  const token = randomToken(32);
  const csrfToken = randomToken(24);
  const ttlMs = rememberMe ? msFromHours(env.REMEMBER_ME_TTL_DAYS * 24) : msFromHours(env.SESSION_TTL_HOURS);
  const id = internalId('sess');

  db.prepare(`INSERT INTO sessions (id, user_id, token_hash, csrf_token, expires_at) VALUES (?, ?, ?, ?, ?)`)
    .run(id, userId, hmac(token), csrfToken, isoAfterMs(ttlMs));

  return { id, token, csrfToken };
}

export function destroySession(token) {
  if (!token) return;
  getDb().prepare('DELETE FROM sessions WHERE token_hash = ?').run(hmac(token));
}

export function getCurrentUser(userId) {
  return getDb().prepare('SELECT id, email, display_name, created_at FROM users WHERE id = ?').get(userId);
}

export function cleanupExpiredSessions() {
  getDb().prepare("DELETE FROM sessions WHERE expires_at <= CURRENT_TIMESTAMP").run();
}
