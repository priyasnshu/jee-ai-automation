import pino from 'pino';
import { env } from '../config/env.js';

export const logger = pino({
  level: env.LOG_LEVEL,
  redact: {
    paths: [
      'req.headers.authorization',
      'req.headers.cookie',
      'password',
      'token',
      'apiKey',
      'secret',
      'botToken'
    ],
    censor: '[REDACTED]'
  },
  base: undefined,
  timestamp: pino.stdTimeFunctions.isoTime
});
