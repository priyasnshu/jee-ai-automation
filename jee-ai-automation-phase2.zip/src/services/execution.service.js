import { getDb } from '../database/index.js';
import { internalId } from '../utils/ids.js';
import { json, safeJsonParse } from '../utils/json.js';

export const STEP_STATUS = Object.freeze(['queued', 'running', 'completed', 'failed', 'skipped', 'cancelled']);

function emitEvent(executionId, eventType, payload = {}) {
  getDb().prepare('INSERT INTO execution_events (execution_id, event_type, payload_json) VALUES (?, ?, ?)')
    .run(executionId, eventType, json(payload));
}

export function createExecution({ userId, instruction, branch = null, confidence = null, topic = null, chapter = null, requestedCount = null, publishToTelegram = false, createGoogleDoc = false, priority = 'normal' }) {
  const db = getDb();
  const id = internalId('exec');
  db.prepare(`INSERT INTO executions
    (id, user_id, branch, confidence, instruction, topic, chapter, status, priority, requested_count, publish_to_telegram, create_google_doc)
    VALUES (?, ?, ?, ?, ?, ?, ?, 'queued', ?, ?, ?, ?)`)
    .run(id, userId, branch, confidence, instruction, topic, chapter, priority, requestedCount, publishToTelegram ? 1 : 0, createGoogleDoc ? 1 : 0);
  emitEvent(id, 'execution.created', { status: 'queued' });
  return getExecution(id, userId);
}

export function getExecution(id, userId) {
  const row = getDb().prepare('SELECT * FROM executions WHERE id = ? AND user_id = ?').get(id, userId);
  if (!row) return null;
  row.router_output = safeJsonParse(row.router_output_json);
  row.steps = getDb().prepare('SELECT * FROM execution_steps WHERE execution_id = ? ORDER BY step_order ASC').all(id);
  for (const step of row.steps) step.metadata = safeJsonParse(step.metadata_json);
  return row;
}

export function listExecutions(userId, limit = 30) {
  const rows = getDb().prepare('SELECT * FROM executions WHERE user_id = ? ORDER BY created_at DESC LIMIT ?').all(userId, Math.min(Math.max(Number(limit) || 30, 1), 100));
  return rows;
}

export function setExecutionRouterOutput(executionId, output) {
  const db = getDb();
  db.prepare(`UPDATE executions SET branch = ?, confidence = ?, topic = ?, chapter = ?, requested_count = ?, publish_to_telegram = ?, create_google_doc = ?, priority = ?, router_output_json = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`)
    .run(output.branch, output.confidence, output.topic ?? null, output.chapter ?? null, output.requested_count ?? null, output.publish_to_telegram ? 1 : 0, output.create_google_doc ? 1 : 0, output.priority, json(output), executionId);
  emitEvent(executionId, 'router.completed', output);
}

export function updateExecutionStatus(executionId, status, extra = {}) {
  const db = getDb();
  const fields = ['status = ?', 'updated_at = CURRENT_TIMESTAMP'];
  const values = [status];
  if (typeof extra.progress === 'number') { fields.push('progress = ?'); values.push(Math.round(extra.progress)); }
  if (extra.errorCode !== undefined) { fields.push('error_code = ?'); values.push(extra.errorCode); }
  if (extra.errorMessage !== undefined) { fields.push('error_message = ?'); values.push(extra.errorMessage); }
  if (extra.status === 'running') fields.push('started_at = COALESCE(started_at, CURRENT_TIMESTAMP)');
  if (status === 'running') fields.push('started_at = COALESCE(started_at, CURRENT_TIMESTAMP)');
  if (['completed','failed','cancelled'].includes(status)) fields.push('completed_at = CURRENT_TIMESTAMP');
  db.prepare(`UPDATE executions SET ${fields.join(', ')} WHERE id = ?`).run(...values, executionId);
  emitEvent(executionId, `execution.${status}`, { status, ...extra });
}

export function createStep(executionId, stepOrder, service, action) {
  const id = internalId('step');
  getDb().prepare(`INSERT INTO execution_steps (id, execution_id, step_order, service, action, status) VALUES (?, ?, ?, ?, ?, 'queued')`)
    .run(id, executionId, stepOrder, service, action);
  emitEvent(executionId, 'step.created', { stepId: id, stepOrder, service, action, status: 'queued' });
  return id;
}

export function updateStep(stepId, status, metadata = {}, errorMessage = null) {
  const db = getDb();
  const existing = db.prepare('SELECT * FROM execution_steps WHERE id = ?').get(stepId);
  if (!existing) return;
  const startedAt = status === 'running' ? "COALESCE(started_at, CURRENT_TIMESTAMP)" : 'started_at';
  const completedAt = ['completed','failed','skipped','cancelled'].includes(status) ? 'CURRENT_TIMESTAMP' : 'completed_at';
  const duration = ['completed','failed','skipped','cancelled'].includes(status) ? 'COALESCE(duration_ms, CAST((julianday(CURRENT_TIMESTAMP) - julianday(COALESCE(started_at, CURRENT_TIMESTAMP))) * 86400000 AS INTEGER))' : 'duration_ms';
  db.prepare(`UPDATE execution_steps SET status = ?, metadata_json = ?, error_message = ?, started_at = ${startedAt}, completed_at = ${completedAt}, duration_ms = ${duration} WHERE id = ?`)
    .run(status, json(metadata), errorMessage, stepId);
  emitEvent(existing.execution_id, 'step.updated', { stepId, status, metadata, errorMessage });
}

export function updateExecutionProgress(executionId, progress) {
  getDb().prepare('UPDATE executions SET progress = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?').run(Math.max(0, Math.min(100, Math.round(progress))), executionId);
  emitEvent(executionId, 'execution.progress', { progress: Math.round(progress) });
}

export function logExecution(executionId, service, action, level, message, metadata = {}) {
  emitEvent(executionId, 'log', { service, action, level, message, metadata });
}

export function listEvents(executionId, afterId = 0) {
  const rows = getDb().prepare('SELECT id, event_type, payload_json, created_at FROM execution_events WHERE execution_id = ? AND id > ? ORDER BY id ASC LIMIT 200').all(executionId, afterId);
  return rows.map(r => ({ id: r.id, event_type: r.event_type, payload: safeJsonParse(r.payload_json, {}), created_at: r.created_at }));
}
