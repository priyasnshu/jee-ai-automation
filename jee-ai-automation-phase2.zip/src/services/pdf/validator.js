import fs from 'node:fs/promises';
import { classifyMime } from '../../middleware/upload.js';
import { isPdfFile } from '../../utils/files.js';

export async function validatePdfInput(file) {
  if (!file) throw new Error('PDF_FILE_MISSING');
  if (classifyMime(file.mime_type) !== 'pdf') throw new Error('FILE_IS_NOT_PDF');
  const stat = await fs.stat(file.absolute_path);
  if (stat.size <= 0) throw new Error('PDF_FILE_EMPTY');
  if (!(await isPdfFile(file.absolute_path))) throw new Error('INVALID_PDF_SIGNATURE');
  return { sizeBytes: stat.size };
}
