import { env } from '../../config/env.js';

export function ocrProviderStatus() {
  return env.OCR_PROVIDER ? { configured: true, provider: env.OCR_PROVIDER } : { configured: false, provider: null };
}

export async function extractScannedPage(_input) {
  if (!env.OCR_PROVIDER) {
    const error = new Error('OCR_PROVIDER_NOT_CONFIGURED');
    error.code = 'OCR_PROVIDER_NOT_CONFIGURED';
    throw error;
  }
  throw new Error(`OCR provider '${env.OCR_PROVIDER}' has no adapter configured in Phase 2.`);
}
