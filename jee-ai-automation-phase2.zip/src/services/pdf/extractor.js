import fs from 'node:fs/promises';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { logger } from '../logger.js';
import { isPdfFile, safeRelativePath } from '../../utils/files.js';
import { env } from '../../config/env.js';

const execFileAsync = promisify(execFile);

async function extractWithPdfJs(filePath) {
  const { getDocument } = await import('pdfjs-dist/legacy/build/pdf.mjs');
  const data = await fs.readFile(filePath);
  const loadingTask = getDocument({ data, useSystemFonts: true, disableFontFace: true, verbosity: 0 });
  const document = await loadingTask.promise;
  const pages = [];
  try {
    for (let pageNumber = 1; pageNumber <= document.numPages; pageNumber += 1) {
      const page = await document.getPage(pageNumber);
      const content = await page.getTextContent();
      const items = content.items.map(item => String(item.str ?? '').trim()).filter(Boolean);
      const text = items.join(' ').replace(/[ \t]+/g, ' ').trim();
      pages.push({ pageNumber, text, extractionStatus: text ? 'extracted' : 'empty' });
      page.cleanup();
    }
  } finally {
    await document.destroy();
  }
  return { pageCount: pages.length, pages, parser: 'pdfjs' };
}

async function extractWithPdftotext(filePath) {
  const { stdout } = await execFileAsync('pdfinfo', [filePath], { timeout: 20_000, maxBuffer: 2 * 1024 * 1024 });
  const match = stdout.match(/^Pages:\s+(\d+)$/m);
  const pageCount = Number(match?.[1] ?? 0);
  if (!pageCount) throw new Error('PDF page count could not be determined.');

  const pages = [];
  for (let pageNumber = 1; pageNumber <= pageCount; pageNumber += 1) {
    const { stdout: text } = await execFileAsync('pdftotext', ['-layout', '-f', String(pageNumber), '-l', String(pageNumber), filePath, '-'], { timeout: 30_000, maxBuffer: 8 * 1024 * 1024 });
    const cleaned = String(text).replace(/\f/g, '').replace(/[ \t]+/g, ' ').trim();
    pages.push({ pageNumber, text: cleaned, extractionStatus: cleaned ? 'extracted' : 'empty' });
  }
  return { pageCount, pages, parser: 'pdftotext' };
}

export async function extractPdfPages({ filePath, relativePath = filePath }) {
  if (!(await isPdfFile(filePath))) throw new Error('INVALID_PDF_SIGNATURE');
  safeRelativePath(relativePath);

  try {
    return await extractWithPdfJs(filePath);
  } catch (error) {
    logger.warn({ err: error, filePath }, 'PDF.js extraction unavailable or failed; attempting pdftotext fallback');
    try {
      return await extractWithPdftotext(filePath);
    } catch (fallbackError) {
      if (env.NODE_ENV === 'test') logger.warn({ err: fallbackError }, 'PDF fallback failed in test mode');
      throw new Error(`PDF extraction failed: ${fallbackError.message}`);
    }
  }
}
