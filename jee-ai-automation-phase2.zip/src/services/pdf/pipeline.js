import path from 'node:path';
import { getDb } from '../../database/index.js';
import { env } from '../../config/env.js';
import { validatePdfInput } from './validator.js';
import { extractAndPersistFile, pageBatches, extractPass, reconcileChunk, persistCanonicalQuestions, detectDuplicates, persistDuplicateCandidates, qualityAudit, detectDiagrams } from '../questions/processing.js';
import { generateDiagram } from '../image/diagram.service.js';
import { updateExecutionStatus, updateExecutionProgress, createStep, updateStep, logExecution } from '../execution.service.js';
import { safeJsonParse, json } from '../../utils/json.js';
import { internalId } from '../../utils/ids.js';

const STEP_COUNT = 11;

function absoluteFilePath(row) {
  return path.resolve(process.cwd(), row.relative_path);
}

function ensureExecutionRunning(executionId) {
  const row = getDb().prepare('SELECT status FROM executions WHERE id=?').get(executionId);
  if (!row) throw new Error('EXECUTION_NOT_FOUND');
  if (['cancelled','failed'].includes(row.status)) {
    const error = new Error('EXECUTION_CANCELLED');
    error.code = 'EXECUTION_CANCELLED';
    throw error;
  }
}

async function runStep(executionId, order, service, action, fn) {
  ensureExecutionRunning(executionId);
  const stepId = createStep(executionId, order, service, action);
  updateStep(stepId, 'running');
  const started = Date.now();
  updateExecutionProgress(executionId, Math.max(1, Math.min(97, Math.round(((order - 1) / STEP_COUNT) * 95) + 1)));
  try {
    const result = await fn();
    updateStep(stepId, 'completed', { durationMs: Date.now() - started, ...(result?.metadata ?? {}) });
    updateExecutionProgress(executionId, Math.max(1, Math.min(97, Math.round((order / STEP_COUNT) * 95))));
    return result;
  } catch (error) {
    updateStep(stepId, 'failed', {}, error.message);
    throw error;
  }
}

function persistCandidates(executionId, file, passNumber, batchKey, items) {
  const db = getDb();
  const insert = db.prepare(`INSERT INTO question_candidates (id,execution_id,file_id,pass_number,batch_key,external_number,page_start,page_end,question_text,options_json,answer,needs_diagram_hint,issues_json,confidence,source_model) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  for (const q of items) {
    insert.run(
      internalId('cand'),
      executionId,
      file.id,
      passNumber,
      batchKey,
      q.external_number,
      q.page_start,
      q.page_end,
      q.question_text,
      json(q.options),
      q.answer,
      q.needs_diagram_hint ? 1 : 0,
      json(q.issues),
      q.confidence,
      env.MOCK_EXTERNAL_SERVICES ? 'mock' : env.GEMINI_MODEL || null
    );
  }
}

export async function processPdfQuestionsExecution({ executionId }) {
  updateExecutionStatus(executionId, 'running', { progress: 1 });
  const db = getDb();
  const execution = db.prepare('SELECT * FROM executions WHERE id=?').get(executionId);
  if (!execution) throw new Error('EXECUTION_NOT_FOUND');

  const files = db.prepare(`SELECT * FROM uploaded_files WHERE user_id=? AND execution_id=? ORDER BY created_at ASC`).all(execution.user_id, executionId);
  const pdfFiles = files.filter(file => file.kind === 'pdf');
  if (!pdfFiles.length) throw new Error('PDF_FILES_REQUIRED');
  if (pdfFiles.length > env.MAX_PDF_COUNT) throw new Error(`MAX_PDF_COUNT_EXCEEDED:${env.MAX_PDF_COUNT}`);

  await runStep(executionId, 1, 'pdf', 'files_uploaded', async () => ({ metadata: { fileCount: pdfFiles.length } }));

  await runStep(executionId, 2, 'pdf', 'pdf_validation', async () => {
    for (const row of pdfFiles) await validatePdfInput({ ...row, absolute_path: absoluteFilePath(row) });
    return { metadata: { validated: pdfFiles.length } };
  });

  const allByFile = [];
  await runStep(executionId, 3, 'pdf', 'pdf_extraction', async () => {
    let pages = 0;
    for (const row of pdfFiles) {
      const extracted = await extractAndPersistFile({ executionId, file: { ...row, absolute_path: absoluteFilePath(row) } });
      pages += extracted.pageCount;
      allByFile.push({ file: row, ...extracted });
    }
    return { metadata: { pages } };
  });

  const batchState = [];
  const aggregate = { pass1: [], pass2: [], canonical: [] };

  await runStep(executionId, 4, 'ai', 'question_extraction_pass_1', async () => {
    for (const item of allByFile) {
      const batches = pageBatches(item.pages.filter(page => page.text.trim()));
      const state = { file: item.file, batches, pass1: [], pass2: [], canonical: [] };
      for (let i = 0; i < batches.length; i += 1) {
        const pass1 = await extractPass(batches[i], 1, item.file.original_name);
        state.pass1.push(pass1);
        aggregate.pass1.push(...pass1);
        persistCandidates(executionId, item.file, 1, `batch-${i + 1}`, pass1);
      }
      batchState.push(state);
    }
    return { metadata: { candidateCount: aggregate.pass1.length } };
  });

  await runStep(executionId, 5, 'ai', 'question_extraction_pass_2', async () => {
    for (const state of batchState) {
      for (let i = 0; i < state.batches.length; i += 1) {
        const pass2 = await extractPass(state.batches[i], 2, state.file.original_name);
        state.pass2.push(pass2);
        aggregate.pass2.push(...pass2);
        persistCandidates(executionId, state.file, 2, `batch-${i + 1}`, pass2);
      }
    }
    return { metadata: { candidateCount: aggregate.pass2.length } };
  });

  await runStep(executionId, 6, 'ai', 'question_reconciliation', async () => {
    for (const state of batchState) {
      for (let i = 0; i < state.batches.length; i += 1) {
        const reconciliation = await reconcileChunk(state.batches[i], state.pass1[i] ?? [], state.pass2[i] ?? [], state.file.original_name);
        const canonical = reconciliation.questions.map(q => ({
          ...q,
          fileId: state.file.id,
          fileName: state.file.original_name,
          batchKey: `batch-${i + 1}`,
          reconciliation: reconciliation.decisions
        }));
        state.canonical.push(canonical);
        aggregate.canonical.push(...canonical);
        db.prepare('INSERT INTO execution_events (execution_id,event_type,payload_json) VALUES (?,?,?)').run(
          executionId,
          'pdf.reconciliation_batch',
          json({ fileId: state.file.id, batch: i + 1, pass1Count: state.pass1[i]?.length ?? 0, pass2Count: state.pass2[i]?.length ?? 0, canonicalCount: canonical.length, decisions: reconciliation.decisions })
        );
      }
    }
    if (!aggregate.canonical.length) throw new Error('NO_QUESTIONS_FOUND');
    const persisted = await persistCanonicalQuestions({ executionId, questions: aggregate.canonical, topic: execution.topic, chapter: execution.chapter, requestedCount: execution.requested_count });
    return { metadata: { canonicalCount: persisted.length, pass1Count: aggregate.pass1.length, pass2Count: aggregate.pass2.length } };
  });

  await runStep(executionId, 7, 'questions', 'duplicate_detection', async () => {
    const pairs = detectDuplicates(executionId);
    const duplicates = await persistDuplicateCandidates(executionId, pairs);
    return { metadata: { candidatePairs: pairs.length, duplicates: duplicates.length } };
  });

  await runStep(executionId, 8, 'questions', 'question_quality_audit', async () => {
    const results = await qualityAudit(executionId);
    return { metadata: { results } };
  });

  await runStep(executionId, 9, 'ai', 'diagram_detection', async () => {
    const results = await detectDiagrams(executionId);
    return { metadata: { results } };
  });

  await runStep(executionId, 10, 'image', 'diagram_generation', async () => {
    const questions = db.prepare(`SELECT * FROM questions WHERE execution_id=? AND needs_diagram=1 AND status<>'rejected' ORDER BY rowid ASC`).all(executionId);
    const generated = [];
    const unavailable = [];
    for (const question of questions) {
      try {
        const result = await generateDiagram({
          executionId,
          question,
          diagramType: question.diagram_type || 'other',
          reason: question.diagram_reason || 'Question requires a diagram based on diagram detection.',
          requiredLabels: safeJsonParse(question.required_labels_json, [])
        });
        generated.push({ questionId: question.id, ...result });
      } catch (error) {
        if (error.code === 'DIAGRAM_GENERATION_NOT_CONFIGURED') {
          unavailable.push({ questionId: question.id, reason: 'Diagram generation is not configured. Manual review is required.' });
          db.prepare('UPDATE questions SET status=\'needs_review\', updated_at=CURRENT_TIMESTAMP WHERE id=?').run(question.id);
        } else {
          throw error;
        }
      }
    }
    return { metadata: { generated, unavailable } };
  });

  await runStep(executionId, 11, 'questions', 'finalization', async () => {
    const summary = db.prepare(`SELECT COUNT(*) total, SUM(status='verified') verified, SUM(status='needs_review') needs_review, SUM(status='rejected') rejected, SUM(duplicate_candidate=1) duplicates, SUM(needs_diagram=1) diagrams FROM questions WHERE execution_id=?`).get(executionId);
    const fileSummary = db.prepare(`SELECT SUM(extraction_status IN ('partial','ocr_required')) extraction_review_required FROM uploaded_files WHERE execution_id=?`).get(executionId);
    const status = summary.total === 0 ? 'failed' : (summary.needs_review > 0 || summary.rejected > 0 || summary.duplicates > 0 || fileSummary.extraction_review_required > 0) ? 'waiting_review' : 'completed';
    updateExecutionStatus(executionId, status, { progress: 100 });
    logExecution(executionId, 'pdf', 'finalization', 'info', `PDF Questions processing ${status}.`, { ...summary, ...fileSummary });
    return { metadata: summary };
  });

  return db.prepare('SELECT * FROM executions WHERE id=?').get(executionId);
}
