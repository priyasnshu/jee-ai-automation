ALTER TABLE uploaded_files ADD COLUMN execution_id TEXT REFERENCES executions(id) ON DELETE SET NULL;
ALTER TABLE uploaded_files ADD COLUMN page_count INTEGER;
ALTER TABLE uploaded_files ADD COLUMN extraction_status TEXT NOT NULL DEFAULT 'pending';
ALTER TABLE uploaded_files ADD COLUMN extraction_error TEXT;

ALTER TABLE questions ADD COLUMN question_number TEXT;
ALTER TABLE questions ADD COLUMN source_page_start INTEGER;
ALTER TABLE questions ADD COLUMN source_page_end INTEGER;
ALTER TABLE questions ADD COLUMN source_reference TEXT;
ALTER TABLE questions ADD COLUMN raw_text TEXT;
ALTER TABLE questions ADD COLUMN confidence REAL;
ALTER TABLE questions ADD COLUMN reconciliation_json TEXT;
ALTER TABLE questions ADD COLUMN duplicate_candidate INTEGER NOT NULL DEFAULT 0;
ALTER TABLE questions ADD COLUMN diagram_type TEXT;
ALTER TABLE questions ADD COLUMN diagram_reason TEXT;
ALTER TABLE questions ADD COLUMN required_labels_json TEXT;

ALTER TABLE question_reviews ADD COLUMN source TEXT;

ALTER TABLE diagrams ADD COLUMN provider TEXT;
ALTER TABLE diagrams ADD COLUMN model TEXT;
ALTER TABLE diagrams ADD COLUMN prompt TEXT;

CREATE TABLE IF NOT EXISTS pdf_pages (
  id TEXT PRIMARY KEY,
  file_id TEXT NOT NULL REFERENCES uploaded_files(id) ON DELETE CASCADE,
  execution_id TEXT REFERENCES executions(id) ON DELETE CASCADE,
  page_number INTEGER NOT NULL,
  text_content TEXT NOT NULL DEFAULT '',
  character_count INTEGER NOT NULL DEFAULT 0,
  extraction_status TEXT NOT NULL DEFAULT 'extracted' CHECK(extraction_status IN ('extracted','empty','failed','ocr_required')),
  extraction_error TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(file_id, page_number)
);
CREATE INDEX IF NOT EXISTS idx_pdf_pages_execution ON pdf_pages(execution_id, page_number);
CREATE INDEX IF NOT EXISTS idx_pdf_pages_file ON pdf_pages(file_id, page_number);

CREATE TABLE IF NOT EXISTS question_candidates (
  id TEXT PRIMARY KEY,
  execution_id TEXT NOT NULL REFERENCES executions(id) ON DELETE CASCADE,
  file_id TEXT REFERENCES uploaded_files(id) ON DELETE SET NULL,
  pass_number INTEGER NOT NULL CHECK(pass_number IN (1,2,3)),
  batch_key TEXT NOT NULL,
  external_number TEXT,
  page_start INTEGER,
  page_end INTEGER,
  question_text TEXT NOT NULL,
  options_json TEXT,
  answer TEXT,
  needs_diagram_hint INTEGER NOT NULL DEFAULT 0,
  issues_json TEXT,
  confidence REAL,
  source_model TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_question_candidates_exec_pass ON question_candidates(execution_id, pass_number);
CREATE INDEX IF NOT EXISTS idx_question_candidates_file ON question_candidates(file_id, page_start, page_end);

CREATE TABLE IF NOT EXISTS question_duplicates (
  id TEXT PRIMARY KEY,
  execution_id TEXT NOT NULL REFERENCES executions(id) ON DELETE CASCADE,
  question_a_id TEXT NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
  question_b_id TEXT NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
  similarity REAL NOT NULL,
  method TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'candidate' CHECK(status IN ('candidate','confirmed','dismissed')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(question_a_id, question_b_id)
);
CREATE INDEX IF NOT EXISTS idx_question_duplicates_exec ON question_duplicates(execution_id, similarity DESC);

CREATE TABLE IF NOT EXISTS question_versions (
  id TEXT PRIMARY KEY,
  question_id TEXT NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
  version_number INTEGER NOT NULL,
  question_text TEXT NOT NULL,
  options_json TEXT,
  answer TEXT,
  change_type TEXT NOT NULL,
  created_by TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(question_id, version_number)
);
CREATE INDEX IF NOT EXISTS idx_question_versions_question ON question_versions(question_id, version_number DESC);

CREATE INDEX IF NOT EXISTS idx_uploaded_files_execution ON uploaded_files(execution_id);
CREATE INDEX IF NOT EXISTS idx_uploaded_files_hash_kind ON uploaded_files(sha256, kind);
CREATE INDEX IF NOT EXISTS idx_questions_execution ON questions(execution_id);
CREATE INDEX IF NOT EXISTS idx_questions_source_file ON questions(source_file_id, source_page_start, source_page_end);
CREATE INDEX IF NOT EXISTS idx_questions_normalized_hash ON questions(normalized_hash);
