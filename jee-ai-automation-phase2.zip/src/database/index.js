import fs from 'node:fs';
import path from 'node:path';
import Database from 'better-sqlite3';
import { env } from '../config/env.js';

const dbPath = path.resolve(process.cwd(), env.DATABASE_URL);
fs.mkdirSync(path.dirname(dbPath), { recursive: true });

let db;

export function getDb() {
  if (!db) {
    db = new Database(dbPath);
    db.pragma('journal_mode = WAL');
    db.pragma('foreign_keys = ON');
    db.pragma('busy_timeout = 5000');
  }
  return db;
}

export function runMigrations() {
  const database = getDb();
  database.exec(`CREATE TABLE IF NOT EXISTS schema_migrations (id TEXT PRIMARY KEY, applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`);
  const dir = path.resolve(process.cwd(), 'src/database/migrations');
  const files = fs.readdirSync(dir).filter(f => f.endsWith('.sql')).sort();
  const applied = new Set(database.prepare('SELECT id FROM schema_migrations').all().map(r => r.id));

  const apply = database.transaction((fileName, sql) => {
    database.exec(sql);
    database.prepare('INSERT INTO schema_migrations (id) VALUES (?)').run(fileName);
  });

  for (const file of files) {
    if (applied.has(file)) continue;
    apply(file, fs.readFileSync(path.join(dir, file), 'utf8'));
  }
}

export function closeDb() {
  if (db) {
    db.close();
    db = undefined;
  }
}
