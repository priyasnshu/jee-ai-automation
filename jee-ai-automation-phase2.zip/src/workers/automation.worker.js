import { Worker } from 'bullmq';
import { redis } from '../queues/redis.js';
import { QUEUE_NAMES, queues } from '../queues/queues.js';
import { env } from '../config/env.js';
import { logger } from '../services/logger.js';
import { updateExecutionStatus, updateExecutionProgress, createStep, updateStep, logExecution, setExecutionRouterOutput } from '../services/execution.service.js';
import { routeInstruction } from '../services/ai/router.service.js';
import { processPdfQuestionsExecution } from '../services/pdf/pipeline.js';
import { regenerateQuestion } from '../services/questions/processing.js';
import { workerHeartbeat } from './heartbeat.js';

async function routeJob(job) {
  const { executionId, instruction, input, inputMetadata } = job.data;
  updateExecutionStatus(executionId, 'running', { progress: 2 });
  const stepId = createStep(executionId, 1, 'ai-router', 'classify automation request');
  updateStep(stepId, 'running');
  try {
    const output = await routeInstruction(input, inputMetadata);
    setExecutionRouterOutput(executionId, output);
    updateStep(stepId, 'completed', { branch: output.branch, confidence: output.confidence });

    if (output.branch === 'pdf_questions') {
      const pdfJob = await queues.pdfProcessing.add('process-pdf-questions', { executionId }, { jobId: `pdf-${executionId}` });
      logExecution(executionId, 'worker', 'pdf-dispatch', 'info', 'PDF Questions branch dispatched to the dedicated PDF worker.', { jobId: pdfJob.id });
      return { executionId, branch: output.branch, confidence: output.confidence, childJobId: String(pdfJob.id) };
    }

    updateExecutionProgress(executionId, 100);
    updateExecutionStatus(executionId, 'waiting_review', { progress: 100 });
    logExecution(executionId, 'worker', 'automation-route', 'info', 'Phase 1 router completed; this branch is intentionally deferred to its implementation phase.', { branch: output.branch, confidence: output.confidence });
    return { executionId, branch: output.branch, confidence: output.confidence };
  } catch (error) {
    updateStep(stepId, 'failed', {}, error.message);
    updateExecutionStatus(executionId, 'failed', { progress: 100, errorCode: 'ROUTER_FAILED', errorMessage: error.message });
    logExecution(executionId, 'worker', 'automation-route', 'error', 'Automation routing failed');
    throw error;
  }
}

const automationWorker = new Worker(QUEUE_NAMES.automation, routeJob, { connection: redis, concurrency: 2 });
const pdfWorker = new Worker(QUEUE_NAMES.pdfProcessing, async job => {
  if (job.name === 'regenerate-question') {
    return regenerateQuestion({ questionId: job.data.questionId, userId: job.data.userId });
  }
  const { executionId } = job.data;
  try {
    const result = await processPdfQuestionsExecution({ executionId });
    return { executionId, status: result.status };
  } catch (error) {
    if (error.code === 'EXECUTION_CANCELLED') {
      updateExecutionStatus(executionId, 'cancelled', { progress: 100, errorCode: error.code, errorMessage: error.message });
    } else {
      updateExecutionStatus(executionId, 'failed', { progress: 100, errorCode: error.code || 'PDF_PROCESSING_FAILED', errorMessage: error.message });
      logExecution(executionId, 'pdf', 'processing', 'error', error.message);
    }
    throw error;
  }
}, { connection: redis, concurrency: 1 });

automationWorker.on('error', err => logger.error({ err }, 'Automation worker error'));
pdfWorker.on('error', err => logger.error({ err }, 'PDF worker error'));
automationWorker.on('completed', job => logger.info({ jobId: job.id }, 'Automation job completed'));
pdfWorker.on('completed', job => logger.info({ jobId: job.id }, 'PDF processing job completed'));
automationWorker.on('failed', (job, err) => logger.error({ jobId: job?.id, err }, 'Automation job failed'));
pdfWorker.on('failed', (job, err) => logger.error({ jobId: job?.id, err }, 'PDF processing job failed'));

setInterval(() => workerHeartbeat('running'), 10_000).unref();
workerHeartbeat('running');

export async function closeAutomationWorker() {
  workerHeartbeat('stopping');
  await Promise.all([automationWorker.close(), pdfWorker.close()]);
}
