import os from 'node:os';
import { getDb } from '../database/index.js';

export function workerHeartbeat(status = 'running') {
  getDb().prepare(`
    INSERT INTO worker_heartbeat (id, process_id, host, status, updated_at)
    VALUES (1, ?, ?, ?, CURRENT_TIMESTAMP)
    ON CONFLICT(id) DO UPDATE SET process_id=excluded.process_id, host=excluded.host, status=excluded.status, updated_at=CURRENT_TIMESTAMP
  `).run(process.pid, os.hostname(), status);
}
