let csrfToken = '';

async function request(url, options = {}) {
  const headers = new Headers(options.headers || {});
  if (options.body && !(options.body instanceof FormData) && !headers.has('Content-Type')) headers.set('Content-Type', 'application/json');
  if (!['GET','HEAD'].includes((options.method || 'GET').toUpperCase()) && csrfToken) headers.set('X-CSRF-Token', csrfToken);
  const response = await fetch(url, { ...options, headers, credentials: 'same-origin' });
  let data = null;
  try { data = await response.json(); } catch {}
  if (!response.ok) {
    const error = new Error(data?.message || data?.error || `Request failed (${response.status})`);
    error.status = response.status; error.data = data; throw error;
  }
  return data;
}

export async function getMe() { const data = await request('/api/auth/me'); csrfToken = data.csrfToken; return data; }
export async function login(body) { const data = await request('/api/auth/login', { method: 'POST', body: JSON.stringify(body) }); csrfToken = data.csrfToken; return data; }
export async function logout() { return request('/api/auth/logout', { method: 'POST' }); }
export async function health() { return request('/api/health'); }
export async function systemConfig() { return request('/api/system-config'); }
export async function uploadFiles(files) { const form = new FormData(); for (const file of files) form.append('files', file); return request('/api/files/upload', { method: 'POST', body: form }); }
export async function previewRouter(payload) { return request('/api/automations/router', { method: 'POST', body: JSON.stringify(payload) }); }
export async function runAutomation(payload) { return request('/api/automations/run', { method: 'POST', body: JSON.stringify(payload) }); }
export async function executions() { return request('/api/automations/executions'); }
export async function execution(id) { return request(`/api/automations/executions/${encodeURIComponent(id)}`); }
export async function currentCsrf() { return csrfToken; }

export async function pdfExecution(id) { return request(`/api/pdf/executions/${encodeURIComponent(id)}`); }
export async function updatePdfQuestion(id, body) { return request(`/api/pdf/questions/${encodeURIComponent(id)}`, { method:'PATCH', body:JSON.stringify(body) }); }
export async function approvePdfQuestion(id) { return request(`/api/pdf/questions/${encodeURIComponent(id)}/approve`, { method:'POST' }); }
export async function rejectPdfQuestion(id) { return request(`/api/pdf/questions/${encodeURIComponent(id)}/reject`, { method:'POST' }); }
export async function regeneratePdfQuestion(id) { return request(`/api/pdf/questions/${encodeURIComponent(id)}/regenerate`, { method:'POST' }); }
export async function finalizePdfExecution(id) { return request(`/api/pdf/executions/${encodeURIComponent(id)}/finalize`, { method:'POST' }); }
