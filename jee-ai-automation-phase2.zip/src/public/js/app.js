import * as api from './api.js';

const state = { user: null, files: [], pdfFiles: [], executions: [], config: null, health: null, selectedExecution: null, stream: null, pdfExecution: null };
const featureMeta = [
  { id:'pdf', title:'PDF Questions', icon:'▤', description:'PDF → questions → three-pass verification → review-ready output.', phase:'Phase 2', enabled:true, branch:'pdf_questions' },
  { id:'news', title:'JEE News', icon:'⌁', description:'Fresh web research → editor → source-aware post.', phase:'Phase 7', enabled:false, branch:'jee_news' },
  { id:'polls', title:'Polls', icon:'◉', description:'Question generation → Telegram poll → 24h lifecycle.', phase:'Phase 4', enabled:false, branch:'polls' },
  { id:'formula', title:'Formula Sheets', icon:'ƒ', description:'Formula collection → validation → sheet generation.', phase:'Phase 5', enabled:false, branch:'formula_sheet' },
  { id:'notes', title:'Notes', icon:'✎', description:'Photo/PDF/topic → structured educational notes.', phase:'Phase 6', enabled:false, branch:'notes' }
];
const viewTitles = { dashboard:['Dashboard','Private control plane for your JEE channel.'], new:['New Automation','Describe, route, queue, and monitor a job.'], executions:['Executions','Persistent background execution history.'], pdf:['PDF Questions','Phase 2 — complete extraction, verification, review, and preview.'], news:['JEE News','Phase 7 — branch processor not enabled yet.'], polls:['Polls','Phase 4 — branch processor not enabled yet.'], formula:['Formula Sheets','Phase 5 — branch processor not enabled yet.'], notes:['Notes','Phase 6 — branch processor not enabled yet.'], scheduler:['Scheduler','Scheduling foundation lands with the branch implementations.'], settings:['Settings','Provider configuration stays server-side.'] };

const $ = selector => document.querySelector(selector);
const $$ = selector => [...document.querySelectorAll(selector)];

function toast(message, kind='') { const el=$('#notice'); el.textContent=message; el.className=`notice ${kind}`; clearTimeout(toast.timer); toast.timer=setTimeout(()=>el.className='notice hidden',4500); }
function formatDate(value){ if(!value)return '—'; const d=new Date(value.includes('Z')?value:`${value}Z`); return Number.isNaN(d.getTime())?value:d.toLocaleString(); }
function statusClass(ok){ return ok ? 'ok' : 'warn'; }

function setAuthVisible(authenticated) {
  $('#loginView').classList.toggle('hidden', authenticated);
  $$('.view').forEach(v=>v.classList.toggle('hidden', !authenticated));
  $('#sidebar').classList.toggle('hidden', !authenticated);
  $('#logoutBtn').classList.toggle('hidden', !authenticated);
}

function showView(name) {
  if (!state.user) return;
  $$('.view').forEach(v=>v.classList.add('hidden'));
  const target = name === 'dashboard' ? $('#dashboardView') : name === 'new' ? $('#newView') : name === 'pdf' ? $('#pdfView') : name === 'executions' ? $('#executionsView') : $('#placeholderView');
  target.classList.remove('hidden');
  const [title, subtitle] = viewTitles[name] || viewTitles.dashboard;
  $('#pageTitle').textContent = title; $('#pageSubtitle').textContent = subtitle;
  $$('.nav-item').forEach(b=>b.classList.toggle('active', b.dataset.view===name));
  if (name === 'dashboard') renderDashboard();
  if (name === 'executions') renderExecutions();
  if (name === 'pdf') { renderPdfExecutions(); }
  if (name !== 'dashboard' && name !== 'new' && name !== 'pdf' && name !== 'executions') {
    const meta = featureMeta.find(x=>x.id===name);
    $('#placeholderTitle').textContent = meta?.title || viewTitles[name]?.[0] || 'Feature';
    $('#placeholderText').textContent = meta?.enabled ? 'This surface is enabled.' : `${meta?.phase || 'A later phase'} is required before this branch can run. The Phase 1 control plane is live, but this branch is intentionally disabled rather than simulated.`;
  }
  $('#sidebar').classList.remove('open');
}

async function refreshHealth(){ try{ state.health=await api.health(); renderStatus(); } catch(e){ state.health={status:'error',database:{ok:false},redis:{ok:false},gemini:{configured:false},telegram:{ok:false},google:{ok:false},worker:{ok:false}}; renderStatus(); } }
async function refreshExecutions(){ try{ const data=await api.executions(); state.executions=data.executions; renderExecutions(); }catch(e){ console.error(e); } }

function renderStatus(){
  const h=state.health||{};
  const items=[
    ['Database',h.database],['Redis',h.redis],['Gemini',h.gemini],['Telegram',h.telegram],['Google',h.google],['Worker',h.worker]
  ];
  $('#statusGrid').innerHTML=items.map(([name,s])=>`<div class="status-card"><h4>${name}</h4><div class="status"><span class="dot ${statusClass(s?.ok)}"></span>${s?.status||'unknown'}</div></div>`).join('');
}

function renderDashboard(){
  renderStatus();
  const all=state.executions||[];
  const success=all.filter(x=>x.status==='completed').length;
  const failed=all.filter(x=>x.status==='failed').length;
  const queued=all.filter(x=>['queued','running'].includes(x.status)).length;
  const scheduled=all.filter(x=>x.scheduled_for).length;
  $('#metrics').innerHTML=[['Executions',all.length],['Completed',success],['Failed',failed],['Active',queued],['Scheduled',scheduled]].slice(0,4).map(([label,val])=>`<div class="metric-card"><div class="value">${val}</div><div class="label">${label}</div></div>`).join('');
  $('#branchGrid').innerHTML=featureMeta.map(meta=>`<div class="branch-card ${meta.enabled?'':'disabled'}"><div class="branch-icon">${meta.icon}</div><h3>${meta.title}</h3><p>${meta.description}</p><div class="branch-foot"><span class="tag">${meta.enabled?'Live':meta.phase}</span>${meta.enabled?`<button class="ghost-button" data-view="new" data-branch="${meta.branch}">Run</button>`:'<span class="tag">Disabled</span>'}</div></div>`).join('');
  renderRecent();
}

function renderRecent(){
  const rows=(state.executions||[]).slice(0,8);
  $('#recentExecutions').innerHTML=rows.length?rows.map(executionRow).join(''):`<div class="panel empty-panel" style="margin:0;max-width:none"><p>No executions yet. Start from New Automation.</p></div>`;
}
function renderExecutions(){ renderPdfExecutions(); $('#allExecutions').innerHTML=(state.executions||[]).length?(state.executions||[]).map(executionRow).join(''):`<div class="panel empty-panel" style="margin:0;max-width:none"><p>No executions yet.</p></div>`; }
function executionRow(ex){ return `<button class="execution-item" data-execution-id="${ex.id}"><div><div class="execution-title">${escapeHtml(ex.instruction)}</div><div class="execution-meta">${ex.branch||'routing pending'} · ${formatDate(ex.created_at)}</div></div><div><span class="status-pill">${ex.status}</span></div></button>`; }
function escapeHtml(v){ return String(v??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;'); }

function collectPayload(){ return { instruction:$('#instruction').value.trim(), branch:$('#branch').value, topic:$('#topic').value.trim(), chapter:$('#chapter').value.trim(), requestedCount:$('#requestedCount').value?Number($('#requestedCount').value):null, publishToTelegram:$('#publishTelegram').checked, createGoogleDoc:$('#createGoogleDoc').checked, fileIds:state.files.map(f=>f.id) }; }
function renderFiles(){ $('#fileList').innerHTML=state.files.map(f=>`<div class="file-chip"><span>${escapeHtml(f.originalName)}</span><span>${f.kind} · ${(f.sizeBytes/1024/1024).toFixed(2)} MB</span></div>`).join(''); }
function renderRouter(output, low=false){ $('#routerPreview').textContent=JSON.stringify(output,null,2); $('#confidenceFill').style.width=`${Math.round((output.confidence||0)*100)}%`; $('#routeMessage').textContent=low?`Low confidence (${Math.round(output.confidence*100)}%). Choose a branch manually before running.`:`Router confidence: ${Math.round(output.confidence*100)}% · branch: ${output.branch}`; }


function pdfExecutionRow(ex) { return `<button class="execution-item" data-pdf-execution-id="${escapeHtml(ex.id)}"><div><div class="execution-title">${escapeHtml(ex.topic || ex.chapter || ex.instruction)}</div><div class="execution-meta">${ex.status} · ${formatDate(ex.created_at)}</div></div><span class="status-pill">${escapeHtml(ex.status)}</span></button>`; }
function renderPdfExecutions(){ const rows=(state.executions||[]).filter(ex=>ex.branch==='pdf_questions'); $('#pdfExecutionList').innerHTML=rows.length?rows.map(pdfExecutionRow).join(''):`<div class="empty-panel"><p>No PDF executions yet.</p></div>`; }
function renderPdfFiles(){ $('#pdfFileList').innerHTML=state.pdfFiles.map(f=>`<div class="file-chip"><span>${escapeHtml(f.originalName)}</span><span>${(f.sizeBytes/1024/1024).toFixed(2)} MB</span></div>`).join(''); }
function pdfPayload(){ return { instruction:$('#pdfInstruction').value.trim(), branch:'pdf_questions', topic:$('#pdfTopic').value.trim(), chapter:$('#pdfChapter').value.trim(), requestedCount:$('#pdfRequestedCount').value?Number($('#pdfRequestedCount').value):null, publishToTelegram:false, createGoogleDoc:false, fileIds:state.pdfFiles.map(f=>f.id) }; }
async function handlePdfFiles(files){ if(!files.length)return; try { const data=await api.uploadFiles([...files]); state.pdfFiles.push(...data.files.filter(f=>f.kind==='pdf')); renderPdfFiles(); if(data.files.some(f=>f.kind!=='pdf')) toast('Only PDF files are used by the PDF Questions branch.','error'); else toast(`${data.files.length} PDF file(s) uploaded.`,'success'); } catch(e){ toast(e.message,'error'); } }
async function handlePdfRun(e){ e.preventDefault(); const payload=pdfPayload(); if(!payload.instruction){toast('Enter the PDF processing instruction.','error');return;} if(!payload.fileIds.length){toast('Upload at least one PDF.','error');return;} try{const data=await api.runAutomation(payload);toast(`PDF execution queued: ${data.executionId}`,'success');state.pdfFiles=[];renderPdfFiles();await refreshExecutions();showPdfExecution(data.executionId);}catch(err){toast(err.message,'error');} }
async function showPdfExecution(id){ try{const data=await api.pdfExecution(id);state.pdfExecution=data;renderPdfPreview(data);}catch(e){toast(e.message,'error');} }
function renderPdfPreview(data){
  $('#pdfPreviewPanel').classList.remove('hidden');
  const s=data.summary||{};
  $('#pdfPreviewTitle').textContent=`PDF Questions · ${data.execution.id}`;
  $('#pdfPreviewSummary').textContent=`${s.total||0} questions · ${s.verified||0} verified · ${s.needs_review||0} needs review · ${s.rejected||0} rejected · ${s.duplicates||0} duplicate candidates · ${s.diagrams||0} diagrams`;
  $('#pdfFinalizeBtn').disabled=Boolean(s.needs_review||s.rejected);
  $('#pdfQuestionsList').innerHTML=(data.questions||[]).map(renderPdfQuestion).join('') || '<div class="empty-panel"><p>No questions were persisted.</p></div>';
}
function renderPdfQuestion(q){
  const issues=(q.issues||[]); const opts=(q.options||[]);
  const cls=q.status==='rejected'?'rejected':q.status==='needs_review'?'needs-review':'';
  const diagram=q.diagram?`<img class="diagram-preview" src="/api/pdf/diagrams/${encodeURIComponent(q.diagram.id)}" alt="Generated educational diagram" loading="lazy" />`:'';
  return `<article class="question-card ${cls}" data-question-card="${q.id}">
    <div class="question-head"><div><div class="question-id">${escapeHtml(q.question_number||q.id)}</div><div class="question-source">${escapeHtml(q.source_filename||'source')} · pages ${escapeHtml(q.source_page_start)}-${escapeHtml(q.source_page_end)} · ${escapeHtml(q.status)}</div></div><span class="status-pill">${escapeHtml(q.status)}</span></div>
    <textarea class="question-textarea" data-question-text>${escapeHtml(q.question_text)}</textarea>
    <div class="option-grid">${opts.map((o,i)=>`<input class="option-input" data-option value="${escapeHtml(o)}" placeholder="Option ${String.fromCharCode(65+i)}" />`).join('')}</div>
    ${issues.length?`<div class="review-issues"><strong>Issues:</strong> ${escapeHtml(issues.join(' · '))}</div>`:''}
    ${q.duplicate_candidate?`<div class="review-issues"><strong>Duplicate candidate:</strong> review against another extracted question before finalizing.</div>`:''}
    ${diagram}
    <div class="question-actions"><button class="ghost-button" data-q-action="save" data-question-id="${q.id}">Save edit</button><button class="ghost-button" data-q-action="approve" data-question-id="${q.id}">Approve</button><button class="ghost-button" data-q-action="reject" data-question-id="${q.id}">Reject</button><button class="ghost-button" data-q-action="regenerate" data-question-id="${q.id}">Regenerate</button></div>
  </article>`;
}
async function handlePdfQuestionAction(action,id,card){
  try{
    if(action==='save'){
      const text=card.querySelector('[data-question-text]').value.trim();
      const options=[...card.querySelectorAll('[data-option]')].map(x=>x.value.trim()).filter(Boolean);
      await api.updatePdfQuestion(id,{questionText:text,options});
      toast('Question edit saved as a new version.','success');
    } else if(action==='approve'){ await api.approvePdfQuestion(id); toast('Question approved.','success'); }
    else if(action==='reject'){ await api.rejectPdfQuestion(id); toast('Question rejected.','success'); }
    else if(action==='regenerate'){ await api.regeneratePdfQuestion(id); toast('Regeneration queued. Refreshing shortly.','success'); }
    if(state.pdfExecution) await showPdfExecution(state.pdfExecution.execution.id);
  }catch(e){toast(e.message,'error');}
}

async function handleFiles(files){ if(!files.length)return; try{ const data=await api.uploadFiles([...files]); state.files.push(...data.files); renderFiles(); toast(`${data.files.length} file(s) uploaded.`, 'success'); }catch(e){ toast(e.message,'error'); } }

async function handlePreview(){ const payload=collectPayload(); if(!payload.instruction){toast('Enter an instruction first.','error');return;} try{const data=await api.previewRouter(payload); renderRouter(data.output,data.lowConfidence); if(data.lowConfidence) toast('Router confidence is low; choose a branch manually before running.','error');}catch(e){toast(e.message,'error');}}

async function handleRun(event){ event.preventDefault(); const payload=collectPayload(); if(!payload.instruction){toast('Enter an instruction.','error');return;} try{const data=await api.runAutomation(payload); toast(`Execution queued: ${data.executionId}`,'success'); showExecution(data.executionId); refreshExecutions(); }catch(e){toast(e.message,'error');}}

async function showExecution(id){ const drawer=$('#executionDrawer'); drawer.classList.remove('hidden'); $('#drawerTitle').textContent=id; $('#drawerStatus').textContent='Loading…'; $('#drawerSteps').innerHTML=''; $('#drawerLogs').textContent=''; try{ const data=await api.execution(id); renderDrawer(data); subscribeExecution(id); }catch(e){toast(e.message,'error');}}
function renderDrawer(data){ state.selectedExecution=data; $('#drawerStatus').textContent=`${data.status} · ${data.branch||'routing pending'} · ${data.progress||0}%`; $('#drawerProgress').style.width=`${data.progress||0}%`; $('#drawerSteps').innerHTML=(data.steps||[]).map(s=>`<div class="step"><div class="state">${s.status==='completed'?'✓':s.status==='running'?'⏳':s.status==='failed'?'!':'○'}</div><div><div class="name">${escapeHtml(s.action)}</div><div class="meta">${s.service} · ${s.status}${s.error_message?` · ${escapeHtml(s.error_message)}`:''}</div></div><div class="meta">${s.duration_ms?`${s.duration_ms}ms`:''}</div></div>`).join(''); }
function subscribeExecution(id){ if(state.stream)state.stream.close(); const es=new EventSource(`/api/automations/executions/${encodeURIComponent(id)}/events`,{withCredentials:true}); state.stream=es; es.onmessage=()=>refreshDrawer(id); es.addEventListener('execution.progress',()=>refreshDrawer(id)); es.addEventListener('execution.completed',()=>refreshDrawer(id)); es.addEventListener('execution.waiting_review',()=>refreshDrawer(id)); es.addEventListener('execution.failed',()=>refreshDrawer(id)); es.onerror=()=>{}; }
async function refreshDrawer(id){ try{const data=await api.execution(id); renderDrawer(data); if(['completed','failed','cancelled'].includes(data.status)&&state.stream){state.stream.close();state.stream=null;} refreshExecutions(); }catch{} }

$('#loginForm').addEventListener('submit',async e=>{e.preventDefault();try{const data=await api.login({email:$('#loginEmail').value.trim(),password:$('#loginPassword').value,rememberMe:$('#rememberMe').checked});state.user=data.user;setAuthVisible(true);$('#userBadge').textContent=data.user.email;showView('dashboard');await Promise.all([refreshHealth(),refreshExecutions()]);}catch(err){toast(err.message,'error');}});
$('#logoutBtn').addEventListener('click',async()=>{try{await api.logout();}finally{state.user=null;setAuthVisible(false);location.reload();}});
$('#mobileMenu').addEventListener('click',()=>$('#sidebar').classList.toggle('open'));
$('#closeDrawer').addEventListener('click',()=>{$('#executionDrawer').classList.add('hidden'); if(state.stream){state.stream.close();state.stream=null;}});
$('#uploadDrop').addEventListener('click',()=>$('#filesInput').click());
$('#filesInput').addEventListener('change',e=>handleFiles(e.target.files));
$('#previewRoute').addEventListener('click',handlePreview);
$('#automationForm').addEventListener('submit',handleRun);


$('#pdfUploadDrop').addEventListener('click',()=>$('#pdfFilesInput').click());
$('#pdfFilesInput').addEventListener('change',e=>handlePdfFiles(e.target.files));
$('#pdfForm').addEventListener('submit',handlePdfRun);
$('#pdfFinalizeBtn').addEventListener('click',async()=>{ if(!state.pdfExecution)return; try{await api.finalizePdfExecution(state.pdfExecution.execution.id);toast('PDF execution finalized.','success');await showPdfExecution(state.pdfExecution.execution.id);await refreshExecutions();}catch(e){toast(e.message,'error');} });
$('#pdfRunNew').addEventListener('click',()=>{ window.scrollTo({top:0,behavior:'smooth'}); $('#pdfInstruction').focus(); });

document.addEventListener('click',e=>{
  const pdfExec=e.target.closest('[data-pdf-execution-id]');
  if(pdfExec){ showPdfExecution(pdfExec.dataset.pdfExecutionId); return; }
  const action=e.target.closest('[data-q-action]');
  if(action){ const card=action.closest('[data-question-card]'); handlePdfQuestionAction(action.dataset.qAction,action.dataset.questionId,card); return; }
});

document.addEventListener('click',e=>{ const viewButton=e.target.closest('[data-view]'); if(viewButton){const view=viewButton.dataset.view; if(viewButton.dataset.branch){$('#branch').value=viewButton.dataset.branch;} showView(view); return;} const row=e.target.closest('[data-execution-id]'); if(row)showExecution(row.dataset.executionId); });

(async function boot(){
  try{ const me=await api.getMe(); state.user=me.user; setAuthVisible(true); $('#userBadge').textContent=me.user.email; showView('dashboard'); await Promise.all([refreshHealth(),refreshExecutions()]); }
  catch{ setAuthVisible(false); $('#loginView').classList.remove('hidden'); $('#pageTitle').textContent='Private dashboard'; $('#pageSubtitle').textContent='Sign in to continue.'; $('#sidebar').classList.add('hidden'); }
})();
