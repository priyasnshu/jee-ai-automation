import { z } from 'zod';

export const BranchEnum = z.enum(['pdf_questions', 'jee_news', 'polls', 'formula_sheet', 'notes']);

export const RouterOutputSchema = z.object({
  branch: BranchEnum,
  confidence: z.number().min(0).max(1),
  topic: z.string().nullable().default(null),
  chapter: z.string().nullable().default(null),
  input_type: z.enum(['text', 'pdf', 'image', 'mixed']).default('text'),
  requested_count: z.number().int().positive().max(1000).nullable().default(null),
  publish_to_telegram: z.boolean().default(false),
  create_google_doc: z.boolean().default(false),
  schedule: z.string().nullable().default(null),
  priority: z.enum(['low', 'normal', 'high']).default('normal')
}).strict();

export const RouterRequestSchema = z.object({
  instruction: z.string().trim().min(1).max(12000),
  branch: z.enum(['auto', 'pdf_questions', 'jee_news', 'polls', 'formula_sheet', 'notes']).default('auto'),
  topic: z.string().trim().max(300).optional().default(''),
  chapter: z.string().trim().max(300).optional().default(''),
  requestedCount: z.number().int().positive().max(1000).nullable().optional().default(null),
  publishToTelegram: z.boolean().optional(),
  createGoogleDoc: z.boolean().optional(),
  fileIds: z.array(z.string()).max(20).optional().default([])
});
