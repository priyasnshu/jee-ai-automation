import { runMigrations, closeDb } from './database/index.js';
import { connectRedis, closeRedis } from './queues/redis.js';
import { closeQueues } from './queues/queues.js';
import { closeAutomationWorker } from './workers/automation.worker.js';
import { logger } from './services/logger.js';

runMigrations();
await connectRedis();
logger.info('Worker process started');

const shutdown = async signal => {
  logger.info({ signal }, 'Worker shutting down');
  try {
    await closeAutomationWorker();
    await closeQueues();
    await closeRedis();
    closeDb();
  } finally {
    process.exit(0);
  }
};

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
