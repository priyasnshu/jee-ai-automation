import { logger } from '../services/logger.js';

export function notFoundHandler(req, res) {
  res.status(404).json({ error: 'not_found', message: 'Resource not found.' });
}

export function errorHandler(err, req, res, _next) {
  const status = Number(err.statusCode || err.status || 500);
  const requestId = req.id || undefined;
  logger.error({ err, requestId, path: req.path }, 'Unhandled request error');
  res.status(status).json({
    error: status >= 500 ? 'internal_error' : 'request_error',
    message: status >= 500 ? 'Internal server error.' : err.message
  });
}
