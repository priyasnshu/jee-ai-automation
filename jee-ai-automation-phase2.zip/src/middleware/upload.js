import multer from 'multer';
import path from 'node:path';
import crypto from 'node:crypto';
import fs from 'node:fs';
import { env } from '../config/env.js';

const root = path.resolve(process.cwd(), 'storage/uploads');
fs.mkdirSync(root, { recursive: true });

const allowed = new Map([
  ['application/pdf', 'pdf'],
  ['image/jpeg', 'image'],
  ['image/png', 'image'],
  ['image/webp', 'image'],
]);

export const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, root),
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase();
      const safeExt = ext && /^\.[a-z0-9]{1,8}$/.test(ext) ? ext : '';
      cb(null, `${Date.now()}_${crypto.randomUUID()}${safeExt}`);
    }
  }),
  limits: {
    files: env.MAX_PDF_COUNT,
    fileSize: Math.max(env.MAX_PDF_SIZE_MB, env.MAX_IMAGE_SIZE_MB) * 1024 * 1024
  },
  fileFilter: (_req, file, cb) => {
    if (!allowed.has(file.mimetype)) return cb(new Error('Unsupported file type. Only PDF/JPEG/PNG/WEBP are allowed.'));
    cb(null, true);
  }
});

export function classifyMime(mimeType) {
  const kind = allowed.get(mimeType);
  if (!kind) throw new Error(`Unsupported MIME type: ${mimeType}`);
  return kind;
}
