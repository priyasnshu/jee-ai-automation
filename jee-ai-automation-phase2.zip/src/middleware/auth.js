import { getDb } from '../database/index.js';
import { hmac } from '../utils/crypto.js';

export const SESSION_COOKIE = 'jee_session';
export const CSRF_HEADER = 'x-csrf-token';

export function requireAuth(req, res, next) {
  const token = req.cookies?.[SESSION_COOKIE];
  if (!token) return res.status(401).json({ error: 'unauthorized', message: 'Authentication required.' });

  const db = getDb();
  const session = db.prepare(`
    SELECT s.id, s.user_id, s.csrf_token, s.expires_at, u.email, u.display_name
    FROM sessions s
    JOIN users u ON u.id = s.user_id
    WHERE s.token_hash = ? AND s.expires_at > CURRENT_TIMESTAMP
  `).get(hmac(token));

  if (!session) return res.status(401).json({ error: 'unauthorized', message: 'Session expired.' });

  db.prepare('UPDATE sessions SET last_seen_at = CURRENT_TIMESTAMP WHERE id = ?').run(session.id);
  req.auth = session;
  next();
}

export function requireCsrf(req, res, next) {
  const method = req.method.toUpperCase();
  if (['GET','HEAD','OPTIONS'].includes(method)) return next();
  const token = req.get(CSRF_HEADER);
  if (!token || !req.auth || token !== req.auth.csrf_token) {
    return res.status(403).json({ error: 'csrf_failed', message: 'Invalid CSRF token.' });
  }
  next();
}
