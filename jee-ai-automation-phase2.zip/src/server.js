import { createServer } from 'node:http';
import { createApp } from './app.js';
import { env } from './config/env.js';
import { connectRedis, closeRedis } from './queues/redis.js';
import { closeDb } from './database/index.js';
import { logger } from './services/logger.js';

await connectRedis();
const app = createApp();
const server = createServer(app);

server.listen(env.PORT, env.HOST, () => {
  logger.info({ host: env.HOST, port: env.PORT }, 'API server started');
});

const shutdown = async signal => {
  logger.info({ signal }, 'API server shutting down');
  server.close(async () => {
    await closeRedis();
    closeDb();
    process.exit(0);
  });
};

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
