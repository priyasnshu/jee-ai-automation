import express from 'express';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import pinoHttp from 'pino-http';
import path from 'node:path';
import { env } from './config/env.js';
import { getDb, runMigrations } from './database/index.js';
import { requestId } from './middleware/request-id.js';
import { requireAuth } from './middleware/auth.js';
import { errorHandler, notFoundHandler } from './middleware/error-handler.js';
import authRoutes from './routes/auth.routes.js';
import healthRoutes from './routes/health.routes.js';
import filesRoutes from './routes/files.routes.js';
import automationRoutes from './routes/automation.routes.js';
import pdfRoutes from './routes/pdf.routes.js';
import { cleanupExpiredSessions } from './services/auth.service.js';
import { logger } from './services/logger.js';

runMigrations();
cleanupExpiredSessions();

export function createApp() {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', env.TRUST_PROXY);

  app.use(helmet({ contentSecurityPolicy: false }));
  app.use(requestId);
  app.use(pinoHttp({ logger }));
  app.use(cookieParser());
  app.use(express.json({ limit: '2mb' }));
  app.use(express.urlencoded({ extended: false, limit: '2mb' }));

  app.get('/api', (_req, res) => res.json({ name: 'JEE AI Automation Platform', phase: 2, status: 'pdf-questions' }));
  app.use('/api', healthRoutes);
  app.use('/api/auth', authRoutes);
  app.use('/api/files', filesRoutes);
  app.use('/api/automations', automationRoutes);
  app.use('/api/pdf', pdfRoutes);
  app.get('/api/system-config', requireAuth, (_req, res) => {
    res.json({
      phase: 2,
      mockExternalServices: env.MOCK_EXTERNAL_SERVICES,
      features: {
        aiRouter: true,
        pdfQuestions: true,
        telegramDelivery: false,
        polls: false,
        formulaSheets: false,
        notes: false,
        jeeNews: false,
        googleDocs: false
      }
    });
  });

  const publicDir = path.resolve(process.cwd(), 'src/public');
  app.use(express.static(publicDir, { index: 'index.html', maxAge: env.NODE_ENV === 'production' ? '1h' : 0 }));

  app.use(notFoundHandler);
  app.use(errorHandler);
  return app;
}
