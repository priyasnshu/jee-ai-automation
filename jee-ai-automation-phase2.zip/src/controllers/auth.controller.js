import { z } from 'zod';
import { authenticateUser, createSession, destroySession } from '../services/auth.service.js';
import { env, isProduction } from '../config/env.js';
import { SESSION_COOKIE, CSRF_HEADER } from '../middleware/auth.js';

const LoginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
  rememberMe: z.boolean().optional().default(false)
});

export async function login(req, res) {
  const parsed = LoginSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'validation_error', details: parsed.error.flatten() });

  const user = await authenticateUser(parsed.data.email, parsed.data.password);
  if (!user) return res.status(401).json({ error: 'invalid_credentials', message: 'Invalid email or password.' });

  const session = createSession(user.id, parsed.data.rememberMe);
  res.cookie(SESSION_COOKIE, session.token, {
    httpOnly: true,
    sameSite: 'strict',
    secure: isProduction,
    path: '/',
    maxAge: parsed.data.rememberMe ? env.REMEMBER_ME_TTL_DAYS * 86400000 : env.SESSION_TTL_HOURS * 3600000
  });

  res.json({ user: { id: user.id, email: user.email, displayName: user.display_name }, csrfToken: session.csrfToken });
}

export function logout(req, res) {
  destroySession(req.cookies?.[SESSION_COOKIE]);
  res.clearCookie(SESSION_COOKIE, { httpOnly: true, sameSite: 'strict', secure: isProduction, path: '/' });
  res.json({ ok: true });
}

export function me(req, res) {
  res.json({ user: { id: req.auth.user_id, email: req.auth.email, displayName: req.auth.display_name }, csrfToken: req.auth.csrf_token });
}

export { CSRF_HEADER };
