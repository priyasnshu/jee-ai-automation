import { getDb } from '../database/index.js';
import { redis } from '../queues/redis.js';
import { env } from '../config/env.js';
import { checkGemini } from '../services/ai/gemini.service.js';
import { logger } from '../services/logger.js';

async function checkRedis() {
  try {
    await redis.ping();
    return { status: 'connected', ok: true };
  } catch (error) {
    return { status: 'error', ok: false, message: error.message };
  }
}

function checkDb() {
  try {
    getDb().prepare('SELECT 1').get();
    return { status: 'connected', ok: true };
  } catch (error) {
    return { status: 'error', ok: false, message: error.message };
  }
}

function checkWorker() {
  try {
    const row = getDb().prepare("SELECT status, updated_at FROM worker_heartbeat WHERE id = 1").get();
    if (!row) return { status: 'not_seen', ok: false };
    const ageMs = Date.now() - new Date(`${row.updated_at}Z`).getTime();
    return { status: ageMs < 30000 ? row.status : 'stale', ok: ageMs < 30000, updatedAt: row.updated_at };
  } catch {
    return { status: 'unknown', ok: false };
  }
}

export async function health(_req, res) {
  const db = checkDb();
  const redisStatus = await checkRedis();
  const gemini = await checkGemini();
  const google = { status: env.GOOGLE_CLIENT_ID && env.GOOGLE_CLIENT_SECRET ? 'configured' : 'not_configured', ok: Boolean(env.GOOGLE_CLIENT_ID && env.GOOGLE_CLIENT_SECRET) };
  const telegram = { status: env.TELEGRAM_BOT_TOKEN && env.TELEGRAM_CHANNEL_ID ? 'configured' : 'not_configured', ok: Boolean(env.TELEGRAM_BOT_TOKEN && env.TELEGRAM_CHANNEL_ID) };
  const worker = checkWorker();
  const ok = db.ok && redisStatus.ok && worker.ok;
  res.status(ok ? 200 : 503).json({ status: ok ? 'ok' : 'degraded', environment: env.NODE_ENV, database: db, redis: redisStatus, gemini, telegram, google, worker });
}
