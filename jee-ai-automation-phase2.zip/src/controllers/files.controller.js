import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import path from 'node:path';
import { isPdfFile, isImageFile, safeRelativePath } from '../utils/files.js';
import { getDb } from '../database/index.js';
import { classifyMime } from '../middleware/upload.js';
import { env } from '../config/env.js';
import { internalId } from '../utils/ids.js';

async function sha256File(filePath) {
  const data = await fs.readFile(filePath);
  return crypto.createHash('sha256').update(data).digest('hex');
}

export async function uploadFiles(req, res) {
  if (!req.files?.length) return res.status(400).json({ error: 'no_files', message: 'At least one file is required.' });
  const db = getDb();
  const validated = [];

  try {
    for (const file of req.files) {
      const kind = classifyMime(file.mimetype);
      const signatureValid = kind === 'pdf' ? await isPdfFile(file.path) : await isImageFile(file.path, file.mimetype);
      const maxBytes = (kind === 'pdf' ? env.MAX_PDF_SIZE_MB : env.MAX_IMAGE_SIZE_MB) * 1024 * 1024;
      if (!signatureValid) throw Object.assign(new Error(`${file.originalname} does not match its declared file type.`), { code:'invalid_file_signature', status:400 });
      if (file.size > maxBytes) throw Object.assign(new Error(`${file.originalname} exceeds the ${kind === 'pdf' ? env.MAX_PDF_SIZE_MB : env.MAX_IMAGE_SIZE_MB} MB limit.`), { code:'file_too_large', status:413 });
      validated.push({ file, kind, hash: await sha256File(file.path) });
    }

    const saved = [];
    const insert = db.prepare(`INSERT INTO uploaded_files (id, user_id, original_name, stored_name, relative_path, mime_type, size_bytes, sha256, kind)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`);
    const transaction = db.transaction(items => {
      for (const item of items) {
        const { file, kind, hash } = item;
        const id = internalId('file');
        const relativePath = path.relative(process.cwd(), file.path).replaceAll(path.sep, '/');
        insert.run(id, req.auth.user_id, file.originalname, file.filename, relativePath, file.mimetype, file.size, hash, kind);
        saved.push({ id, originalName:file.originalname, mimeType:file.mimetype, sizeBytes:file.size, kind, sha256:hash });
      }
    });
    transaction(validated);
    return res.status(201).json({ files:saved });
  } catch (error) {
    await Promise.all((req.files ?? []).map(file => fs.unlink(file.path).catch(() => {})));
    const status = error.status ?? 400;
    return res.status(status).json({ error:error.code || 'upload_failed', message:error.message });
  }
}

export function listFiles(req, res) {
  const rows = getDb().prepare(`SELECT id, original_name, mime_type, size_bytes, kind, status, sha256, created_at FROM uploaded_files WHERE user_id = ? ORDER BY created_at DESC LIMIT 100`).all(req.auth.user_id);
  res.json({ files: rows });
}


export async function downloadFile(req, res) {
  const row = getDb().prepare('SELECT * FROM uploaded_files WHERE id=? AND user_id=?').get(req.params.id, req.auth.user_id);
  if (!row) return res.status(404).json({ error:'not_found', message:'File not found.' });
  const relative = safeRelativePath(row.relative_path);
  const absolute = path.resolve(process.cwd(), relative);
  if (!absolute.startsWith(path.resolve(process.cwd(), 'storage') + path.sep)) return res.status(403).json({ error:'forbidden' });
  try {
    await fs.access(absolute);
  } catch {
    return res.status(404).json({ error:'missing_file', message:'Stored file is unavailable.' });
  }
  res.type(row.mime_type);
  res.setHeader('Content-Disposition', `inline; filename*=UTF-8''${encodeURIComponent(row.original_name)}`);
  return res.sendFile(absolute);
}
