import { queues } from '../queues/queues.js';
import { getDb } from '../database/index.js';
import { RouterRequestSchema } from '../validators/router.js';
import { routeInstruction } from '../services/ai/router.service.js';
import { createExecution, getExecution, listExecutions, listEvents } from '../services/execution.service.js';
import { env } from '../config/env.js';
import { internalId } from '../utils/ids.js';

function getUserFiles(userId, fileIds) {
  if (!fileIds?.length) return [];
  const placeholders = fileIds.map(() => '?').join(',');
  return getDb().prepare(`SELECT id, original_name, mime_type, size_bytes, kind FROM uploaded_files WHERE user_id = ? AND id IN (${placeholders})`)
    .all(userId, ...fileIds);
}

export async function previewRouter(req, res) {
  const parsed = RouterRequestSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'validation_error', details: parsed.error.flatten() });
  const files = getUserFiles(req.auth.user_id, parsed.data.fileIds);
  if (files.length !== parsed.data.fileIds.length) return res.status(400).json({ error: 'invalid_files', message: 'One or more files do not belong to your account.' });
  const output = await routeInstruction(parsed.data, files.map(f => ({ id: f.id, originalName: f.original_name, mimeType: f.mime_type, sizeBytes: f.size_bytes, kind: f.kind })));
  res.json({ output, lowConfidence: output.confidence < env.AUTO_PUBLISH_CONFIDENCE_THRESHOLD });
}

export async function runAutomation(req, res) {
  const parsed = RouterRequestSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'validation_error', details: parsed.error.flatten() });
  const files = getUserFiles(req.auth.user_id, parsed.data.fileIds);
  if (files.length !== parsed.data.fileIds.length) return res.status(400).json({ error: 'invalid_files', message: 'One or more files do not belong to your account.' });

  const initialBranch = parsed.data.branch !== 'auto' ? parsed.data.branch : null;
  const execution = createExecution({
    userId: req.auth.user_id,
    instruction: parsed.data.instruction,
    branch: initialBranch,
    confidence: parsed.data.branch !== 'auto' ? 1 : null,
    topic: parsed.data.topic || null,
    chapter: parsed.data.chapter || null,
    requestedCount: parsed.data.requestedCount ?? null,
    publishToTelegram: parsed.data.publishToTelegram ?? false,
    createGoogleDoc: parsed.data.createGoogleDoc ?? false,
    priority: 'normal'
  });

  if (files.length) {
    const placeholders = files.map(() => '?').join(',');
    getDb().prepare(`UPDATE uploaded_files SET execution_id = ? WHERE user_id = ? AND id IN (${placeholders})`).run(execution.id, req.auth.user_id, ...files.map(f => f.id));
  }

  const job = await queues.automation.add('route-automation', {
    executionId: execution.id,
    userId: req.auth.user_id,
    instruction: parsed.data.instruction,
    input: parsed.data,
    inputMetadata: files.map(f => ({ id: f.id, originalName: f.original_name, mimeType: f.mime_type, sizeBytes: f.size_bytes, kind: f.kind }))
  }, {
    priority: parsed.data.branch !== 'auto' ? 5 : 5,
    jobId: execution.id
  });

  res.status(202).json({ executionId: execution.id, jobId: String(job.id) });
}

export function executions(req, res) {
  res.json({ executions: listExecutions(req.auth.user_id, Number(req.query.limit) || 30) });
}

export function execution(req, res) {
  const row = getExecution(req.params.id, req.auth.user_id);
  if (!row) return res.status(404).json({ error: 'not_found', message: 'Execution not found.' });
  res.json(row);
}

export function executionEvents(req, res) {
  const row = getExecution(req.params.id, req.auth.user_id);
  if (!row) return res.status(404).json({ error: 'not_found', message: 'Execution not found.' });

  let lastId = Number(req.get('last-event-id') || req.query.after || 0);
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no'
  });

  const send = () => {
    const events = listEvents(req.params.id, lastId);
    for (const event of events) {
      res.write(`id: ${event.id}\n`);
      res.write(`event: ${event.event_type}\n`);
      res.write(`data: ${JSON.stringify(event)}\n\n`);
      lastId = event.id;
    }
  };

  send();
  const timer = setInterval(send, 1000);
  const close = () => clearInterval(timer);
  req.on('close', close);
}


export function pdfExecutions(req, res) {
  const rows = getDb().prepare("SELECT * FROM executions WHERE user_id=? AND branch='pdf_questions' ORDER BY created_at DESC LIMIT ?").all(req.auth.user_id, Math.min(Math.max(Number(req.query.limit)||30,1),100));
  res.json({ executions: rows });
}

export function processPdf(req, res) {
  req.body = { ...(req.body || {}), branch: 'pdf_questions' };
  return runAutomation(req, res);
}

export function pdfExecution(req, res) {
  const row = getExecution(req.params.id, req.auth.user_id);
  if (!row || row.branch !== 'pdf_questions') return res.status(404).json({ error: 'not_found', message: 'PDF execution not found.' });
  const db = getDb();
  const summary = db.prepare(`SELECT COUNT(*) total,
      SUM(status='verified') verified,
      SUM(status='needs_review') needs_review,
      SUM(status='rejected') rejected,
      SUM(duplicate_candidate=1) duplicates,
      SUM(needs_diagram=1) diagrams
    FROM questions WHERE execution_id=?`).get(req.params.id);
  const questions = db.prepare(`SELECT q.*, f.original_name source_filename
    FROM questions q LEFT JOIN uploaded_files f ON f.id=q.source_file_id
    WHERE q.execution_id=? ORDER BY q.rowid ASC`).all(req.params.id);
  for (const q of questions) {
    q.options = safeJson(q.options_json, []);
    q.issues = db.prepare('SELECT * FROM question_reviews WHERE question_id=? ORDER BY created_at DESC, version DESC LIMIT 1').get(q.id)?.issues_json ? safeJson(db.prepare('SELECT issues_json FROM question_reviews WHERE question_id=? ORDER BY created_at DESC, version DESC LIMIT 1').get(q.id).issues_json, []) : [];
    q.versions = db.prepare('SELECT * FROM question_versions WHERE question_id=? ORDER BY version_number DESC').all(q.id);
    q.diagram = db.prepare('SELECT id,diagram_type,provider,model,created_at FROM diagrams WHERE question_id=? ORDER BY created_at DESC LIMIT 1').get(q.id) || null;
  }
  const files = db.prepare('SELECT id,original_name,size_bytes,mime_type,page_count,extraction_status,extraction_error,sha256 FROM uploaded_files WHERE execution_id=? ORDER BY created_at').all(req.params.id);
  res.json({ execution: row, summary, files, questions });
}

function safeJson(value, fallback) {
  try { return JSON.parse(value ?? 'null') ?? fallback; } catch { return fallback; }
}

function getOwnedQuestion(questionId, userId) {
  return getDb().prepare(`SELECT q.*, e.user_id FROM questions q JOIN executions e ON e.id=q.execution_id WHERE q.id=? AND e.user_id=?`).get(questionId, userId);
}

export function updateQuestion(req, res) {
  const question = getOwnedQuestion(req.params.id, req.auth.user_id);
  if (!question) return res.status(404).json({ error: 'not_found', message: 'Question not found.' });
  const { questionText, options, answer } = req.body || {};
  if (typeof questionText !== 'string' || !questionText.trim()) return res.status(400).json({ error: 'validation_error', message: 'questionText is required.' });
  if (options !== undefined && (!Array.isArray(options) || options.some(option => typeof option !== 'string'))) return res.status(400).json({ error: 'validation_error', message: 'options must be an array of strings.' });
  const db=getDb();
  const nextVersion = (db.prepare('SELECT COALESCE(MAX(version_number),0)+1 next FROM question_versions WHERE question_id=?').get(question.id).next);
  const finalOptions = options ?? safeJson(question.options_json, []);
  db.prepare('UPDATE questions SET question_text=?, raw_text=?, options_json=?, answer=?, status=\'needs_review\', updated_at=CURRENT_TIMESTAMP WHERE id=?').run(questionText.trim(), questionText.trim(), JSON.stringify(finalOptions), answer ?? null, question.id);
  db.prepare(`INSERT INTO question_versions (id,question_id,version_number,question_text,options_json,answer,change_type,created_by) VALUES (?,?,?,?,?,?,?,?)`).run(`qv_${Date.now()}_${Math.random().toString(36).slice(2,8)}`,question.id,nextVersion,questionText.trim(),JSON.stringify(finalOptions),answer??null,'manual_edit',req.auth.user_id);
  res.json({ ok:true, version:nextVersion });
}

export function approveQuestion(req, res) {
  return setQuestionReviewStatus(req, res, 'verified');
}

export function rejectQuestion(req, res) {
  return setQuestionReviewStatus(req, res, 'rejected');
}

function setQuestionReviewStatus(req, res, status) {
  const question = getOwnedQuestion(req.params.id, req.auth.user_id);
  if (!question) return res.status(404).json({ error:'not_found', message:'Question not found.' });
  const db=getDb();
  const version=db.prepare('SELECT COALESCE(MAX(version_number),0) + 1 next FROM question_versions WHERE question_id=?').get(question.id).next;
  db.prepare('UPDATE questions SET status=?, updated_at=CURRENT_TIMESTAMP WHERE id=?').run(status,question.id);
  db.prepare(`INSERT INTO question_reviews (id,question_id,reviewer_type,version,status,issues_json,source) VALUES (?,?,?,?,?,?,?)`).run(`review_${Date.now()}_${Math.random().toString(36).slice(2,8)}`,question.id,'human',version,status,'[]','dashboard');
  res.json({ ok:true,status });
}



export async function downloadDiagram(req,res) {
  const row = getDb().prepare(`SELECT d.* FROM diagrams d JOIN questions q ON q.id=d.question_id JOIN executions e ON e.id=q.execution_id WHERE d.id=? AND e.user_id=?`).get(req.params.id, req.auth.user_id);
  if (!row) return res.status(404).json({error:'not_found',message:'Diagram not found.'});
  const path = row.file_path;
  try { await (await import('node:fs/promises')).access(path); } catch { return res.status(404).json({error:'missing_file',message:'Stored diagram is unavailable.'}); }
  return res.sendFile(path);
}

export async function finalizePdfExecution(req,res) {
  const row=getExecution(req.params.id,req.auth.user_id);
  if(!row || row.branch!=='pdf_questions') return res.status(404).json({error:'not_found',message:'PDF execution not found.'});
  const db=getDb();
  const summary=db.prepare(`SELECT COUNT(*) total,SUM(status='needs_review') needs_review,SUM(status='rejected') rejected FROM questions WHERE execution_id=?`).get(req.params.id);
  if(summary.needs_review || summary.rejected) return res.status(409).json({error:'review_required',message:'All questions must be approved and no questions can remain rejected before finalization.',summary});
  db.prepare("UPDATE executions SET status='completed', progress=100, completed_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP WHERE id=?").run(req.params.id);
  res.json({ok:true,status:'completed'});
}

export async function regenerateQuestionEndpoint(req,res){
  const question=getOwnedQuestion(req.params.id,req.auth.user_id);
  if(!question) return res.status(404).json({error:'not_found',message:'Question not found.'});
  const job = await queues.pdfProcessing.add('regenerate-question', { questionId:req.params.id, userId:req.auth.user_id }, { jobId:internalId('regen') });
  return res.status(202).json({ok:true,jobId:String(job.id),status:'queued'});
}
