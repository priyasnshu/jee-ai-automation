import { Queue } from 'bullmq';
import { redis } from './redis.js';

export const QUEUE_NAMES = Object.freeze({
  automation: 'automation-router',
  pdfProcessing: 'pdf-processing',
  aiProcessing: 'ai-processing',
  diagramGeneration: 'diagram-generation',
  newsResearch: 'news-research',
  pollGeneration: 'poll-generation',
  pollExpiration: 'poll-expiration',
  formulaGeneration: 'formula-generation',
  notesProcessing: 'notes-processing',
  telegramDelivery: 'telegram-delivery',
  googleDocs: 'google-docs',
  cleanup: 'cleanup'
});

export function queueOptions() {
  return {
    connection: redis,
    defaultJobOptions: {
      attempts: 3,
      backoff: { type: 'exponential', delay: 2000 },
      removeOnComplete: { age: 86400, count: 1000 },
      removeOnFail: { age: 604800, count: 2000 }
    }
  };
}

export const queues = Object.fromEntries(
  Object.entries(QUEUE_NAMES).map(([key, name]) => [key, new Queue(name, queueOptions())])
);

export async function closeQueues() {
  await Promise.all(Object.values(queues).map(q => q.close()));
}
