import IORedis from 'ioredis';
import { env } from '../config/env.js';

export const redis = new IORedis(env.REDIS_URL, {
  maxRetriesPerRequest: null,
  enableReadyCheck: true,
  lazyConnect: true,
  connectionName: 'jee-ai-automation'
});

export async function connectRedis() {
  if (redis.status === 'wait') await redis.connect();
  return redis;
}

export async function closeRedis() {
  if (redis.status !== 'end') await redis.quit();
}
