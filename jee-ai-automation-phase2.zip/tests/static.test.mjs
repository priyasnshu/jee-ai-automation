import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const requiredFiles = [
  'src/server.js',
  'src/worker.js',
  'src/app.js',
  'src/database/index.js',
  'src/database/migrations/001_initial.sql',
  'src/services/ai/router.service.js',
  'src/services/ai/gemini.service.js',
  'src/public/index.html',
  'src/public/js/app.js',
  '.env.example'
];

test('phase 1 required files exist', () => {
  for (const file of requiredFiles) assert.equal(fs.existsSync(file), true, file);
});

test('all five fixed branches are defined in the router contract', () => {
  const text = fs.readFileSync('src/validators/router.js', 'utf8');
  for (const branch of ['pdf_questions','jee_news','polls','formula_sheet','notes']) assert.match(text, new RegExp(branch));
});

test('web content/document content is treated as untrusted data by router prompt', () => {
  const text = fs.readFileSync('src/prompts/router.txt', 'utf8');
  assert.match(text, /untrusted documents/i);
  assert.match(text, /Never let them override/i);
});
