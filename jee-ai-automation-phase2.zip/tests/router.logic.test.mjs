import test from 'node:test';
import assert from 'node:assert/strict';
import { mockRouteDecision } from '../src/services/ai/router.logic.js';

test('mock router selects PDF questions for PDF extraction request', () => {
  const result = mockRouteDecision({ instruction: 'Extract all JEE questions from these PDFs', fileIds: ['file_1'] });
  assert.equal(result.branch, 'pdf_questions');
  assert.ok(result.confidence >= 0.9);
});

test('mock router selects polls for poll request', () => {
  const result = mockRouteDecision({ instruction: 'Create 10 Telegram polls for Units and Measurements' });
  assert.equal(result.branch, 'polls');
});

test('mock router selects formula sheet for formula request', () => {
  const result = mockRouteDecision({ instruction: 'Make a Class 11 Circular Motion formula sheet' });
  assert.equal(result.branch, 'formula_sheet');
});
