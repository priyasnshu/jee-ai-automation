import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { normalizeMathText, normalizeForHash } from '../src/utils/math.js';
import { similarityScore } from '../src/utils/similarity.js';
import { reconcileCandidateSets, uniqueCanonicalQuestions, heuristicQuestionAudit, detectDiagramTypeHeuristic } from '../src/services/questions/pure.logic.js';

const root = process.cwd();

test('Phase 2 migration adds per-page PDF storage', () => {
  const sql = fs.readFileSync(path.join(root, 'src/database/migrations/002_pdf_questions.sql'), 'utf8');
  assert.match(sql, /CREATE TABLE IF NOT EXISTS pdf_pages/);
  assert.match(sql, /UNIQUE\(file_id, page_number\)/);
});

test('Phase 2 migration stores independent question candidates', () => {
  const sql = fs.readFileSync(path.join(root, 'src/database/migrations/002_pdf_questions.sql'), 'utf8');
  assert.match(sql, /CREATE TABLE IF NOT EXISTS question_candidates/);
  assert.match(sql, /pass_number INTEGER NOT NULL/);
});

test('Phase 2 migration stores duplicate provenance and versions', () => {
  const sql = fs.readFileSync(path.join(root, 'src/database/migrations/002_pdf_questions.sql'), 'utf8');
  assert.match(sql, /CREATE TABLE IF NOT EXISTS question_duplicates/);
  assert.match(sql, /CREATE TABLE IF NOT EXISTS question_versions/);
});

test('Phase 2 environment exposes PDF batching and OCR configuration', () => {
  const env = fs.readFileSync(path.join(root, 'src/config/env.js'), 'utf8');
  assert.match(env, /MAX_PDF_BATCH_CHARS/);
  assert.match(env, /OCR_PROVIDER/);
});

test('math normalization safely converts common educational notation', () => {
  const result = normalizeMathText('v = u + at; x^2 <= 4; \\theta and \\pi');
  assert.equal(result.safe, true);
  assert.match(result.text, /x²/);
  assert.match(result.text, /≤/);
  assert.match(result.text, /θ/);
  assert.match(result.text, /π/);
});

test('unsafe/unrecognized LaTeX is flagged instead of guessed', () => {
  const result = normalizeMathText('Answer uses \\unknowncommand{broken');
  assert.equal(result.safe, false);
});

test('question hashes ignore punctuation and case', () => {
  assert.equal(normalizeForHash('Calculate:  V = U + AT!'), normalizeForHash('calculate v u at'));
});

test('similarity recognizes substantially repeated question wording', () => {
  const score = similarityScore('Calculate the percentage error when x is 10 ± 0.5', 'Find the percentage error when x is 10 +/- 0.5');
  assert.ok(score > 0.45);
});

test('similarity stays low for unrelated question text', () => {
  const score = similarityScore('Find the least count of a screw gauge.', 'A ray strikes a plane mirror. State reflection law.');
  assert.ok(score < 0.35);
});

test('independent reconciliation adds a question found only by Pass 2', () => {
  const pass1 = [{ external_number:'1', page_start:1, page_end:1, question_text:'Find speed.', options:[], confidence:.9, issues:[] }];
  const pass2 = [...pass1, { external_number:'2', page_start:2, page_end:2, question_text:'Find acceleration.', options:[], confidence:.9, issues:[] }];
  const result = reconcileCandidateSets(pass1, pass2);
  assert.equal(result.questions.length, 2);
  assert.equal(result.decisions.some(d => d.action === 'added'), true);
});

test('canonical deduplication merges repeated page spans and keeps widest span', () => {
  const result = uniqueCanonicalQuestions([
    { question_text:'Find acceleration', page_start:4, page_end:4, options:['A','B'], issues:[] },
    { question_text:'Find acceleration', page_start:4, page_end:5, options:['A','B','C','D'], issues:['continued'] }
  ]);
  assert.equal(result.length, 1);
  assert.equal(result[0].page_end, 5);
  assert.equal(result[0].options.length, 4);
});

test('quality audit flags missing numbering and low confidence', () => {
  const result = heuristicQuestionAudit({ question_text:'Find x.', options:[], external_number:null, confidence:.5 });
  assert.equal(result.status, 'needs_review');
  assert.ok(result.issues.length >= 2);
});

test('diagram heuristic detects inclined plane questions', () => {
  assert.equal(detectDiagramTypeHeuristic('A block slides down an inclined plane.'), 'inclined_plane');
});

test('diagram heuristic does not require a diagram for ordinary algebra', () => {
  assert.equal(detectDiagramTypeHeuristic('Solve 2x + 3 = 9.'), 'other');
});

test('acceptance PDF exists and Poppler can extract all 20 question markers', () => {
  const fixture = path.join(root, 'tests/fixtures/phase2-acceptance.pdf');
  assert.equal(fs.existsSync(fixture), true);
  const text = execFileSync('pdftotext', ['-layout', fixture, '-'], { encoding:'utf8' });
  const markers = text.match(/\bQ(?:uestion)?\d{1,2}[.)]/gi) ?? [];
  // Poppler normalization may insert a space after Question in other fixtures; this fixture uses Q1. style.
  assert.equal(markers.length, 20);
  assert.match(text, /the instrument has a least count/);
});

test('Phase 2 route and worker contracts are present', () => {
  const routes = fs.readFileSync(path.join(root, 'src/routes/pdf.routes.js'), 'utf8');
  const worker = fs.readFileSync(path.join(root, 'src/workers/automation.worker.js'), 'utf8');
  assert.match(routes, /\/executions\/:id/);
  assert.match(routes, /\/questions\/:id\/regenerate/);
  assert.match(worker, /QUEUE_NAMES\.pdfProcessing/);
  assert.match(worker, /processPdfQuestionsExecution/);
});

test('PDF prompts explicitly enforce the untrusted-document boundary', () => {
  for (const file of ['pdf-extraction.txt','question-review.txt','question-reconciliation.txt','question-quality-audit.txt']) {
    const text = fs.readFileSync(path.join(root,'src/prompts',file),'utf8').toLowerCase();
    assert.match(text, /untrusted/);
  }
});
