# Deployment

Production deployment is delivered in Phase 9. The Phase 1 code already separates API and worker processes so they can be placed in separate containers/services later.
