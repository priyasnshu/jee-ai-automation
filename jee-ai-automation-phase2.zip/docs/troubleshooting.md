# Troubleshooting

## Redis disconnected
Check `REDIS_URL` and verify Redis is reachable from the server.

## Login fails
Run `npm run seed` after setting `ADMIN_EMAIL` and `ADMIN_PASSWORD`.

## Gemini router unavailable
Confirm `MOCK_EXTERNAL_SERVICES=false`, `GEMINI_API_KEY`, and `GEMINI_MODEL` are set. Check server logs for the sanitized provider error.
