# Google Docs / Drive

Google integration is intentionally not implemented until Phase 8. Phase 1 keeps the configuration surface in `.env` and execution flags in SQLite.
