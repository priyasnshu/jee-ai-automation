# Architecture — Phase 1

Browser dashboard -> Express REST/SSE API -> services/controllers -> SQLite + Redis/BullMQ -> worker.

The AI router is intentionally narrow: it classifies the request into one of the five fixed branch identifiers and returns structured metadata. It does not execute branch logic.

Long-running work is never kept inside the HTTP request. `POST /api/automations/run` creates an execution and enqueues a BullMQ job. The worker owns execution progress.

The later phases plug their branch controllers/services into the same execution/queue contracts without rewriting the foundation.
