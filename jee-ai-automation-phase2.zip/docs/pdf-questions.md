# PDF Questions — Phase 2

## Flow

Dashboard upload → execution → PDF validation → page extraction → independent Pass 1 → independent Pass 2 → reconciliation → duplicate detection → quality audit → diagram detection → diagram generation → finalization/review.

## Security

PDF text is always treated as untrusted data. It is inserted into explicitly delimited prompt sections and cannot override the application instructions. Uploaded filenames are never used as storage paths.

## Extraction

The preferred parser is `pdfjs-dist`. The implementation has a page-scoped `pdftotext` fallback for environments where PDF.js is unavailable. Every stored page has its source file, page number, extracted text, character count, and extraction status.

## Three-pass completeness

Pass 1 extracts question candidates. Pass 2 independently searches the same source pages for missed questions, missing options, numbering gaps, and continuation pages. Pass 3 reconciles both candidate sets against the original source pages and stores reconciliation decisions as execution events.

## Review states

`verified` = extraction passed the automated audit.
`needs_review` = an uncertainty, duplicate candidate, missing data, or configuration issue requires a human decision.
`rejected` = user rejected the question.

The execution stays `waiting_review` while review is required.

## Diagram generation

Diagram detection is separate from image generation. A diagram is generated only when detection returns `needs_diagram=true`. With `MOCK_EXTERNAL_SERVICES=true`, a deterministic SVG is created for testing. With mocks disabled, the configured `IMAGE_PROVIDER`/`IMAGE_MODEL` must be available; otherwise the affected question is marked `needs_review` instead of pretending the diagram was generated.

## OCR

Image-only/scanned pages are marked `ocr_required`. The service exposes an OCR provider interface through `OCR_PROVIDER`, but Phase 2 intentionally does not pretend to have a configured OCR backend when none is supplied.
