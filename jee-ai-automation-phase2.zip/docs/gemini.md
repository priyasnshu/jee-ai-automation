# Gemini

Phase 1 uses the official `@google/genai` JavaScript SDK. Set `GEMINI_API_KEY` and the currently supported `GEMINI_MODEL` in `.env` when `MOCK_EXTERNAL_SERVICES=false`.

The AI Router requests structured JSON and validates the returned object with Zod before persistence.
