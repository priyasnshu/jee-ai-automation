# Setup

1. Install Node.js 22+ and Redis 7+.
2. Copy `.env.example` to `.env`.
3. Set `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `SESSION_SECRET`, and `REDIS_URL`.
4. Run `npm install`.
5. Run `npm run migrate`.
6. Run `npm run seed`.
7. Start `npm run server` and `npm run worker`.
