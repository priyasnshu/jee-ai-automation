# Web Search

Search integration is intentionally not implemented until Phase 7. Provider selection remains configurable through `SEARCH_PROVIDER` and `SEARCH_API_KEY`.
