# Environment

See `.env.example`. Model/provider identifiers are configurable because external APIs change. Never commit `.env`.
