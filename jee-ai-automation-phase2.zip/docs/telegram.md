# Telegram

Telegram integration is intentionally not implemented until Phase 3. Phase 1 stores publishing intent in execution metadata but does not send messages.
