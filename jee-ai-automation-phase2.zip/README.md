# JEE AI Automation Platform — Phase 1

Private, single-user JEE/education automation control plane. This phase establishes the production-oriented foundation: authentication, SQLite persistence, Redis/BullMQ job infrastructure, secure uploads, AI routing, execution tracking, SSE progress, health checks, and a responsive dashboard.

## Phase 1 boundary

Implemented:
- Private single-user login/session/CSRF protection
- SQLite schema + migration runner
- Redis/BullMQ queue infrastructure
- Background automation-router worker
- Secure PDF/image upload foundation
- Gemini Router integration through `@google/genai` with structured JSON validation
- Mock mode for local development
- Execution/step/event logging and live SSE updates
- Responsive dashboard and New Automation screen
- Health endpoint and dependency status

Not yet implemented as live branch processors: PDF question extraction, Telegram delivery, polls, formula sheets, notes, news, Google Docs/Drive. The dashboard marks these as Phase 2+ rather than pretending they work.

## Requirements

- Node.js 22+
- Redis 7+
- npm 10+

## Setup

```bash
cp .env.example .env
npm install
npm run migrate
npm run seed
```

Set a real `ADMIN_PASSWORD` before production. For local testing, `MOCK_EXTERNAL_SERVICES=true` means the router does not call Gemini/Telegram/Google/search/image providers.

Start the API:

```bash
npm run server
```

Start the worker in another terminal:

```bash
npm run worker
```

Open `http://localhost:3000`.

## Redis

Local Redis:

```bash
redis-server
```

Or connect `REDIS_URL` to a managed/private Redis instance.

## Gemini

For real routing set:

```env
MOCK_EXTERNAL_SERVICES=false
GEMINI_API_KEY=...
GEMINI_MODEL=...
```

`GEMINI_MODEL` is intentionally not hardcoded because model availability changes over time.

## Tests / verification

```bash
npm test
npm run lint
npm run build
```

The project uses Node's built-in test runner. The build/lint scripts perform static validation in addition to unit tests.

## API quick reference

- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/health`
- `GET /api/me`
- `POST /api/files/upload`
- `POST /api/automations/router`
- `POST /api/automations/run`
- `GET /api/executions`
- `GET /api/executions/:id`
- `GET /api/executions/:id/events`

All write endpoints except login require the authenticated session and CSRF header.

## Security notes

- Secrets stay server-side.
- Session cookies are HttpOnly and SameSite=strict; Secure is enabled automatically in production.
- CSRF tokens are bound to the session.
- Uploads are stored outside the public directory and are referenced by internal file IDs.
- MIME type and extension are both validated.
- Upload filenames are not used as storage paths.
- Logs use structured JSON and do not include secrets.
- Uploaded PDFs, OCR text, images, and web content are untrusted data. They are never treated as system instructions.

## Phase 2 — PDF Questions

The PDF Questions branch is now implemented end-to-end through the review boundary. It accepts one or more PDFs, validates their signatures and limits, extracts pages one-by-one, runs independent extraction Pass 1 and Pass 2, reconciles both against the original page text, detects duplicates, audits question quality, detects required diagrams, and generates diagrams when a configured image provider is available.

The final execution is automatically marked `waiting_review` whenever extracted content is uncertain, duplicate candidates exist, source pages require OCR/manual review, or diagram generation is not configured for a required diagram. It is marked `completed` only when no question remains in `needs_review` or `rejected`.

Phase 2 does not deliver anything to Telegram or Google Docs. Those remain later phases.

### PDF limits

`MAX_PDF_COUNT` controls the number of PDFs per execution, `MAX_PDF_SIZE_MB` controls each PDF's size, `MAX_QUESTIONS` caps final canonical questions, and `MAX_PDF_BATCH_CHARS` controls the source-text batch size sent to the AI extraction stage.

### PDF processing

PDF.js is the preferred Node parser. The implementation also has a Poppler `pdftotext` page-by-page fallback for environments where PDF.js is unavailable. Scanned/image-only pages are flagged as `ocr_required`; Phase 2 does not silently invent OCR output.

### Diagram configuration

Set `IMAGE_PROVIDER=gemini` and `IMAGE_MODEL=<your currently supported image-capable Gemini model>` when real diagram generation is desired. Keep `MOCK_EXTERNAL_SERVICES=true` for deterministic local tests.
