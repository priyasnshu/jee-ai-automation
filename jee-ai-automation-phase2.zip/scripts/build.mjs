import { existsSync } from 'node:fs';
const required = [
  'src/server.js',
  'src/worker.js',
  'src/database/migrations/001_initial.sql',
  'src/public/index.html',
  'src/public/js/app.js',
  '.env.example'
];
for (const file of required) {
  if (!existsSync(file)) throw new Error(`Missing required build file: ${file}`);
}
console.log('Static build validation passed.');
