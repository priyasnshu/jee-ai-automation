import { execFileSync } from 'node:child_process';
import { readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';

function walk(dir) {
  const out = [];
  for (const entry of readdirSync(dir)) {
    const p = join(dir, entry);
    const s = statSync(p);
    if (s.isDirectory() && !['node_modules', '.git', 'storage'].includes(entry)) out.push(...walk(p));
    else if (s.isFile() && p.endsWith('.js')) out.push(p);
  }
  return out;
}
const files = walk('src').concat(walk('scripts')).concat(walk('tests'));
for (const file of files) execFileSync(process.execPath, ['--check', file], { stdio: 'inherit' });
console.log(`Syntax check passed for ${files.length} JavaScript files.`);
