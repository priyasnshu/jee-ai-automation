import bcrypt from 'bcryptjs';
import { getDb } from '../src/database/index.js';
import crypto from 'node:crypto';
import { env } from '../src/config/env.js';

const db = getDb();
const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(env.ADMIN_EMAIL);
const passwordHash = await bcrypt.hash(env.ADMIN_PASSWORD, 12);

if (existing) {
  db.prepare('UPDATE users SET password_hash = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?').run(passwordHash, existing.id);
  console.log(`Updated admin password for ${env.ADMIN_EMAIL}`);
} else {
  db.prepare(`INSERT INTO users (id, email, password_hash, display_name) VALUES (?, ?, ?, ?)`)
    .run(`user_${crypto.randomUUID()}`, env.ADMIN_EMAIL, passwordHash, 'Admin');
  console.log(`Created admin user ${env.ADMIN_EMAIL}`);
}
