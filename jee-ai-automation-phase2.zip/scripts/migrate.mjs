import { runMigrations } from '../src/database/index.js';
await runMigrations();
console.log('Migrations complete.');
