# Run Phase 1 using only an Android tablet

This is the easiest method for the uploaded Phase 1 project. GitHub Codespaces gives you a cloud Linux development machine and a browser-based VS Code editor, so you do not need to install Node.js on the tablet. GitHub also supports forwarding your running port to a browser tab. Personal GitHub accounts include a monthly Codespaces allowance; it is not an always-on 24/7 server.

## Step 1 — Create a private GitHub repository

On github.com, create a new private repository, for example:

`jee-ai-automation`

You do not need an `index.html` at repository root.

## Step 2 — Create a Codespace

Open the repository.

Tap **Code** → **Codespaces** → **Create codespace on main**.

Wait until the browser editor opens.

## Step 3 — Put the ZIP into the Codespace

Download the project ZIP to your tablet first.

In the Codespace browser editor, use the Explorer's upload action to upload:

`jee-ai-automation-phase1-tablet.zip`

Then open the terminal.

## Step 4 — Extract the project into the repository root

Run:

```bash
unzip -q jee-ai-automation-phase1-tablet.zip -d .tmp-project
cp -a .tmp-project/jee-ai-automation/. .
rm -rf .tmp-project jee-ai-automation-phase1-tablet.zip
```

Check the root:

```bash
ls
```

You should see `package.json`, `src`, `.devcontainer`, `scripts`, and `docs`.

## Step 5 — Install Node dependencies and Redis

Run:

```bash
sudo apt-get update
sudo apt-get install -y redis-server
npm install --no-audit --no-fund
```

Codespaces already provides a Linux development environment. The project requires Node.js 22+.
Check:

```bash
node -v
```

If it is not Node 22 or newer, run:

```bash
nvm install 22
nvm use 22
```

## Step 6 — Start Redis

Run:

```bash
redis-server --daemonize yes --bind 127.0.0.1 --port 6379
redis-cli ping
```

The second command should return:

`PONG`

## Step 7 — Create the environment file

Run:

```bash
cp .env.example .env
```

For Phase 1 you do NOT need Telegram, Google, Search, or Gemini credentials because the project defaults to mock external services for development.

Your important local values should be:

```env
NODE_ENV=development
PORT=3000
HOST=0.0.0.0
DATABASE_URL=./storage/app.sqlite
REDIS_URL=redis://127.0.0.1:6379
SESSION_SECRET=put-a-random-secret-here-at-least-32-characters
ADMIN_EMAIL=admin@example.com
ADMIN_PASSWORD=Phase1Test@12345
MOCK_EXTERNAL_SERVICES=true
```

Generate a session secret with:

```bash
node -e "console.log(require('node:crypto').randomBytes(32).toString('hex'))"
```

Copy that output into `SESSION_SECRET`.

## Step 8 — Initialize the database

Run:

```bash
npm run migrate
npm run seed
```

This creates the SQLite database and the admin account.

Login will be:

Email: `admin@example.com`

Password: `Phase1Test@12345`

Change the password before real/private production use.

## Step 9 — Start the server and worker

The easiest one-command method is:

```bash
npm run start:all
```

This starts both:

- the API server on port 3000
- the background worker

Keep this terminal running while testing.

## Step 10 — Open the dashboard

Codespaces should recognize port 3000.

Open the **PORTS** panel.

Find port `3000`.

Tap the browser/globe icon or **Open in Browser**.

GitHub documents that forwarded ports let you access applications running in a Codespace from your browser.

## Step 11 — Login

Use:

`admin@example.com`

and

`Phase1Test@12345`

## Step 12 — Test Phase 1

At this stage the following should work:

- private login
- dashboard
- PDF/image upload foundation
- AI router in mock mode
- execution creation
- Redis/BullMQ queueing
- background worker
- execution status/events
- logs
- health/status indicators

The five real content branches are deliberately NOT active yet. They are later phases.

## Step 13 — Save changes to GitHub

After you verify the project works:

```bash
git add .
git commit -m "Set up Phase 1"
git push
```

If Git asks for identity:

```bash
git config --global user.name "Your GitHub Name"
git config --global user.email "your-github-email@example.com"
```

## Important Codespaces limitation

This is excellent for building and testing from a tablet, but it is not a permanent 24/7 server. Codespaces has a monthly included-usage quota on personal accounts and can stop when inactive or when the included usage is exhausted. For true 24/7 operation later, deploy the same repository to a persistent VPS/cloud server.
