import 'dotenv/config';
import { z } from 'zod';

const boolString = z.enum(['true', 'false']).transform(v => v === 'true');
const num = (fallback) => z.coerce.number().int().positive().default(fallback);

const schema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: num(3000),
  HOST: z.string().default('0.0.0.0'),
  DATABASE_URL: z.string().min(1).default('./storage/app.sqlite'),
  REDIS_URL: z.string().url().default('redis://127.0.0.1:6379'),
  SESSION_SECRET: z.string().min(32),
  SESSION_TTL_HOURS: num(12),
  REMEMBER_ME_TTL_DAYS: num(30),
  ADMIN_EMAIL: z.string().email(),
  ADMIN_PASSWORD: z.string().min(12),
  GEMINI_API_KEY: z.string().optional().default(''),
  GEMINI_MODEL: z.string().optional().default(''),
  TELEGRAM_BOT_TOKEN: z.string().optional().default(''),
  TELEGRAM_CHANNEL_ID: z.string().optional().default(''),
  GOOGLE_CLIENT_ID: z.string().optional().default(''),
  GOOGLE_CLIENT_SECRET: z.string().optional().default(''),
  GOOGLE_REDIRECT_URI: z.string().optional().default(''),
  SEARCH_PROVIDER: z.string().optional().default(''),
  SEARCH_API_KEY: z.string().optional().default(''),
  IMAGE_PROVIDER: z.string().optional().default(''),
  IMAGE_MODEL: z.string().optional().default(''),
  AUTO_PUBLISH: boolString.default('false'),
  AUTO_PUBLISH_CONFIDENCE_THRESHOLD: z.coerce.number().min(0).max(1).default(0.9),
  POLL_EXPIRATION_HOURS: z.coerce.number().positive().default(24),
  MAX_PDF_COUNT: num(20),
  MAX_PDF_SIZE_MB: num(25),
  MAX_IMAGE_SIZE_MB: num(10),
  MAX_QUESTIONS: num(200),
  MAX_AI_RETRIES: num(3),
  MOCK_EXTERNAL_SERVICES: boolString.default('true'),
  LOG_LEVEL: z.enum(['fatal','error','warn','info','debug','trace']).default('info'),
  TRUST_PROXY: z.coerce.number().int().min(0).default(0),
});

const parsed = schema.safeParse(process.env);
if (!parsed.success) {
  console.error('Invalid environment configuration:');
  console.error(parsed.error.flatten().fieldErrors);
  process.exit(1);
}

export const env = parsed.data;
export const isProduction = env.NODE_ENV === 'production';
