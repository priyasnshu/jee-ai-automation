import { GoogleGenAI } from '@google/genai';
import { env } from '../../config/env.js';
import { logger } from '../logger.js';

let client;

function getClient() {
  if (!env.GEMINI_API_KEY) throw new Error('GEMINI_API_KEY is not configured.');
  client ??= new GoogleGenAI({ apiKey: env.GEMINI_API_KEY });
  return client;
}

export async function geminiStructuredJson({ prompt, responseSchema, model = env.GEMINI_MODEL }) {
  if (!model) throw new Error('GEMINI_MODEL is not configured.');
  const ai = getClient();
  const response = await ai.models.generateContent({
    model,
    contents: prompt,
    config: {
      responseMimeType: 'application/json',
      responseSchema
    }
  });
  const text = response.text?.trim();
  if (!text) throw new Error('Gemini returned an empty response.');
  return JSON.parse(text);
}

export async function checkGemini() {
  if (env.MOCK_EXTERNAL_SERVICES) return { status: 'mock', configured: true };
  if (!env.GEMINI_API_KEY || !env.GEMINI_MODEL) return { status: 'not_configured', configured: false };
  try {
    return { status: 'configured', configured: true };
  } catch (error) {
    logger.warn({ err: error }, 'Gemini configuration check failed');
    return { status: 'error', configured: false };
  }
}
