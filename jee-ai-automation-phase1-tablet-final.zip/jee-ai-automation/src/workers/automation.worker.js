import { Worker, QueueEvents } from 'bullmq';
import { redis } from '../queues/redis.js';
import { QUEUE_NAMES } from '../queues/queues.js';
import { getDb } from '../database/index.js';
import { env } from '../config/env.js';
import { logger } from '../services/logger.js';
import {
  updateExecutionStatus,
  updateExecutionProgress,
  createStep,
  updateStep,
  logExecution,
  setExecutionRouterOutput
} from '../services/execution.service.js';
import { routeInstruction } from '../services/ai/router.service.js';
import { workerHeartbeat } from './heartbeat.js';

const worker = new Worker(QUEUE_NAMES.automation, async job => {
  const { executionId, userId, instruction, input, inputMetadata } = job.data;
  updateExecutionStatus(executionId, 'running', { progress: 5 });
  logExecution(executionId, 'worker', 'automation-route', 'info', 'Automation routing started');

  const stepId = createStep(executionId, 1, 'ai-router', 'classify automation request');
  updateStep(stepId, 'running');
  updateExecutionProgress(executionId, 15);

  try {
    const output = await routeInstruction(input, inputMetadata);
    setExecutionRouterOutput(executionId, output);
    updateStep(stepId, 'completed', { branch: output.branch, confidence: output.confidence });
    updateExecutionProgress(executionId, 100);

    const nextStatus = 'waiting_review';
    updateExecutionStatus(executionId, nextStatus, { progress: 100 });
    logExecution(executionId, 'worker', 'automation-route', 'info', `Phase 1 routing complete; branch processor is intentionally not executed until its implementation phase.`, { branch: output.branch, confidence: output.confidence });

    return { executionId, branch: output.branch, confidence: output.confidence };
  } catch (error) {
    updateStep(stepId, 'failed', {}, error.message);
    updateExecutionStatus(executionId, 'failed', { progress: 100, errorCode: 'ROUTER_FAILED', errorMessage: error.message });
    logExecution(executionId, 'worker', 'automation-route', 'error', 'Automation routing failed');
    throw error;
  }
});

worker.on('error', err => logger.error({ err }, 'Automation worker error'));
worker.on('completed', job => logger.info({ jobId: job.id }, 'Automation job completed'));
worker.on('failed', (job, err) => logger.error({ jobId: job?.id, err }, 'Automation job failed'));

const events = new QueueEvents(QUEUE_NAMES.automation, { connection: redis });

setInterval(() => workerHeartbeat('running'), 10_000).unref();
workerHeartbeat('running');

export async function closeAutomationWorker() {
  workerHeartbeat('stopping');
  await events.close();
  await worker.close();
}
