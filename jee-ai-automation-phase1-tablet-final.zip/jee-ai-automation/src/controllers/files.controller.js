import fs from 'node:fs/promises';
import crypto from 'node:crypto';
import path from 'node:path';
import { getDb } from '../database/index.js';
import { classifyMime } from '../middleware/upload.js';
import { env } from '../config/env.js';
import { internalId } from '../utils/ids.js';

async function sha256File(filePath) {
  const data = await fs.readFile(filePath);
  return crypto.createHash('sha256').update(data).digest('hex');
}

export async function uploadFiles(req, res) {
  if (!req.files?.length) return res.status(400).json({ error: 'no_files', message: 'At least one file is required.' });
  const db = getDb();
  const saved = [];

  for (const file of req.files) {
    const kind = classifyMime(file.mimetype);
    const maxBytes = (kind === 'pdf' ? env.MAX_PDF_SIZE_MB : env.MAX_IMAGE_SIZE_MB) * 1024 * 1024;
    if (file.size > maxBytes) {
      await fs.unlink(file.path).catch(() => {});
      return res.status(413).json({ error: 'file_too_large', message: `${file.originalname} exceeds the ${kind === 'pdf' ? env.MAX_PDF_SIZE_MB : env.MAX_IMAGE_SIZE_MB} MB limit.` });
    }

    const hash = await sha256File(file.path);
    const id = internalId('file');
    const relativePath = path.relative(process.cwd(), file.path).replaceAll(path.sep, '/');
    db.prepare(`INSERT INTO uploaded_files (id, user_id, original_name, stored_name, relative_path, mime_type, size_bytes, sha256, kind)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(id, req.auth.user_id, file.originalname, file.filename, relativePath, file.mimetype, file.size, hash, kind);

    saved.push({ id, originalName: file.originalname, mimeType: file.mimetype, sizeBytes: file.size, kind, sha256: hash });
  }

  res.status(201).json({ files: saved });
}

export function listFiles(req, res) {
  const rows = getDb().prepare(`SELECT id, original_name, mime_type, size_bytes, kind, status, sha256, created_at FROM uploaded_files WHERE user_id = ? ORDER BY created_at DESC LIMIT 100`).all(req.auth.user_id);
  res.json({ files: rows });
}
