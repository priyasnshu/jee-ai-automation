import { queues } from '../queues/queues.js';
import { getDb } from '../database/index.js';
import { RouterRequestSchema } from '../validators/router.js';
import { routeInstruction } from '../services/ai/router.service.js';
import { createExecution, getExecution, listExecutions, listEvents } from '../services/execution.service.js';
import { env } from '../config/env.js';

function getUserFiles(userId, fileIds) {
  if (!fileIds?.length) return [];
  const placeholders = fileIds.map(() => '?').join(',');
  return getDb().prepare(`SELECT id, original_name, mime_type, size_bytes, kind FROM uploaded_files WHERE user_id = ? AND id IN (${placeholders})`)
    .all(userId, ...fileIds);
}

export async function previewRouter(req, res) {
  const parsed = RouterRequestSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'validation_error', details: parsed.error.flatten() });
  const files = getUserFiles(req.auth.user_id, parsed.data.fileIds);
  if (files.length !== parsed.data.fileIds.length) return res.status(400).json({ error: 'invalid_files', message: 'One or more files do not belong to your account.' });
  const output = await routeInstruction(parsed.data, files.map(f => ({ id: f.id, originalName: f.original_name, mimeType: f.mime_type, sizeBytes: f.size_bytes, kind: f.kind })));
  res.json({ output, lowConfidence: output.confidence < env.AUTO_PUBLISH_CONFIDENCE_THRESHOLD });
}

export async function runAutomation(req, res) {
  const parsed = RouterRequestSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'validation_error', details: parsed.error.flatten() });
  const files = getUserFiles(req.auth.user_id, parsed.data.fileIds);
  if (files.length !== parsed.data.fileIds.length) return res.status(400).json({ error: 'invalid_files', message: 'One or more files do not belong to your account.' });

  const initialBranch = parsed.data.branch !== 'auto' ? parsed.data.branch : null;
  const execution = createExecution({
    userId: req.auth.user_id,
    instruction: parsed.data.instruction,
    branch: initialBranch,
    confidence: parsed.data.branch !== 'auto' ? 1 : null,
    topic: parsed.data.topic || null,
    chapter: parsed.data.chapter || null,
    requestedCount: parsed.data.requestedCount ?? null,
    publishToTelegram: parsed.data.publishToTelegram ?? false,
    createGoogleDoc: parsed.data.createGoogleDoc ?? false,
    priority: 'normal'
  });

  const job = await queues.automation.add('route-automation', {
    executionId: execution.id,
    userId: req.auth.user_id,
    instruction: parsed.data.instruction,
    input: parsed.data,
    inputMetadata: files.map(f => ({ id: f.id, originalName: f.original_name, mimeType: f.mime_type, sizeBytes: f.size_bytes, kind: f.kind }))
  }, {
    priority: parsed.data.branch !== 'auto' ? 5 : 5,
    jobId: execution.id
  });

  res.status(202).json({ executionId: execution.id, jobId: String(job.id) });
}

export function executions(req, res) {
  res.json({ executions: listExecutions(req.auth.user_id, Number(req.query.limit) || 30) });
}

export function execution(req, res) {
  const row = getExecution(req.params.id, req.auth.user_id);
  if (!row) return res.status(404).json({ error: 'not_found', message: 'Execution not found.' });
  res.json(row);
}

export function executionEvents(req, res) {
  const row = getExecution(req.params.id, req.auth.user_id);
  if (!row) return res.status(404).json({ error: 'not_found', message: 'Execution not found.' });

  let lastId = Number(req.get('last-event-id') || req.query.after || 0);
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no'
  });

  const send = () => {
    const events = listEvents(req.params.id, lastId);
    for (const event of events) {
      res.write(`id: ${event.id}\n`);
      res.write(`event: ${event.event_type}\n`);
      res.write(`data: ${JSON.stringify(event)}\n\n`);
      lastId = event.id;
    }
  };

  send();
  const timer = setInterval(send, 1000);
  const close = () => clearInterval(timer);
  req.on('close', close);
}
