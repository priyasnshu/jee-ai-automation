import { Router } from 'express';
import { upload } from '../middleware/upload.js';
import { uploadFiles, listFiles } from '../controllers/files.controller.js';
import { requireAuth, requireCsrf } from '../middleware/auth.js';
const router = Router();
router.get('/', requireAuth, listFiles);
router.post('/upload', requireAuth, requireCsrf, upload.array('files', 20), uploadFiles);
export default router;
