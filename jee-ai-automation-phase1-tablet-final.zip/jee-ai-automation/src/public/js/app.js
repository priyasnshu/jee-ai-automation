import * as api from './api.js';

const state = { user: null, files: [], executions: [], config: null, health: null, selectedExecution: null, stream: null };
const featureMeta = [
  { id:'pdf', title:'PDF Questions', icon:'▤', description:'PDF → questions → three-pass verification → future delivery.', phase:'Phase 2', enabled:false, branch:'pdf_questions' },
  { id:'news', title:'JEE News', icon:'⌁', description:'Fresh web research → editor → source-aware post.', phase:'Phase 7', enabled:false, branch:'jee_news' },
  { id:'polls', title:'Polls', icon:'◉', description:'Question generation → Telegram poll → 24h lifecycle.', phase:'Phase 4', enabled:false, branch:'polls' },
  { id:'formula', title:'Formula Sheets', icon:'ƒ', description:'Formula collection → validation → sheet generation.', phase:'Phase 5', enabled:false, branch:'formula_sheet' },
  { id:'notes', title:'Notes', icon:'✎', description:'Photo/PDF/topic → structured educational notes.', phase:'Phase 6', enabled:false, branch:'notes' }
];
const viewTitles = { dashboard:['Dashboard','Private control plane for your JEE channel.'], new:['New Automation','Describe, route, queue, and monitor a job.'], executions:['Executions','Persistent background execution history.'], pdf:['PDF Questions','Phase 2 — branch processor not enabled yet.'], news:['JEE News','Phase 7 — branch processor not enabled yet.'], polls:['Polls','Phase 4 — branch processor not enabled yet.'], formula:['Formula Sheets','Phase 5 — branch processor not enabled yet.'], notes:['Notes','Phase 6 — branch processor not enabled yet.'], scheduler:['Scheduler','Scheduling foundation lands with the branch implementations.'], settings:['Settings','Provider configuration stays server-side.'] };

const $ = selector => document.querySelector(selector);
const $$ = selector => [...document.querySelectorAll(selector)];

function toast(message, kind='') { const el=$('#notice'); el.textContent=message; el.className=`notice ${kind}`; clearTimeout(toast.timer); toast.timer=setTimeout(()=>el.className='notice hidden',4500); }
function formatDate(value){ if(!value)return '—'; const d=new Date(value.includes('Z')?value:`${value}Z`); return Number.isNaN(d.getTime())?value:d.toLocaleString(); }
function statusClass(ok){ return ok ? 'ok' : 'warn'; }

function setAuthVisible(authenticated) {
  $('#loginView').classList.toggle('hidden', authenticated);
  $$('.view').forEach(v=>v.classList.toggle('hidden', !authenticated));
  $('#sidebar').classList.toggle('hidden', !authenticated);
  $('#logoutBtn').classList.toggle('hidden', !authenticated);
}

function showView(name) {
  if (!state.user) return;
  $$('.view').forEach(v=>v.classList.add('hidden'));
  const target = name === 'dashboard' ? $('#dashboardView') : name === 'new' ? $('#newView') : name === 'executions' ? $('#executionsView') : $('#placeholderView');
  target.classList.remove('hidden');
  const [title, subtitle] = viewTitles[name] || viewTitles.dashboard;
  $('#pageTitle').textContent = title; $('#pageSubtitle').textContent = subtitle;
  $$('.nav-item').forEach(b=>b.classList.toggle('active', b.dataset.view===name));
  if (name === 'dashboard') renderDashboard();
  if (name === 'executions') renderExecutions();
  if (name !== 'dashboard' && name !== 'new' && name !== 'executions') {
    const meta = featureMeta.find(x=>x.id===name);
    $('#placeholderTitle').textContent = meta?.title || viewTitles[name]?.[0] || 'Feature';
    $('#placeholderText').textContent = meta?.enabled ? 'This surface is enabled.' : `${meta?.phase || 'A later phase'} is required before this branch can run. The Phase 1 control plane is live, but this branch is intentionally disabled rather than simulated.`;
  }
  $('#sidebar').classList.remove('open');
}

async function refreshHealth(){ try{ state.health=await api.health(); renderStatus(); } catch(e){ state.health={status:'error',database:{ok:false},redis:{ok:false},gemini:{configured:false},telegram:{ok:false},google:{ok:false},worker:{ok:false}}; renderStatus(); } }
async function refreshExecutions(){ try{ const data=await api.executions(); state.executions=data.executions; renderExecutions(); }catch(e){ console.error(e); } }

function renderStatus(){
  const h=state.health||{};
  const items=[
    ['Database',h.database],['Redis',h.redis],['Gemini',h.gemini],['Telegram',h.telegram],['Google',h.google],['Worker',h.worker]
  ];
  $('#statusGrid').innerHTML=items.map(([name,s])=>`<div class="status-card"><h4>${name}</h4><div class="status"><span class="dot ${statusClass(s?.ok)}"></span>${s?.status||'unknown'}</div></div>`).join('');
}

function renderDashboard(){
  renderStatus();
  const all=state.executions||[];
  const success=all.filter(x=>x.status==='completed').length;
  const failed=all.filter(x=>x.status==='failed').length;
  const queued=all.filter(x=>['queued','running'].includes(x.status)).length;
  const scheduled=all.filter(x=>x.scheduled_for).length;
  $('#metrics').innerHTML=[['Executions',all.length],['Completed',success],['Failed',failed],['Active',queued],['Scheduled',scheduled]].slice(0,4).map(([label,val])=>`<div class="metric-card"><div class="value">${val}</div><div class="label">${label}</div></div>`).join('');
  $('#branchGrid').innerHTML=featureMeta.map(meta=>`<div class="branch-card ${meta.enabled?'':'disabled'}"><div class="branch-icon">${meta.icon}</div><h3>${meta.title}</h3><p>${meta.description}</p><div class="branch-foot"><span class="tag">${meta.enabled?'Live':meta.phase}</span>${meta.enabled?`<button class="ghost-button" data-view="new" data-branch="${meta.branch}">Run</button>`:'<span class="tag">Disabled</span>'}</div></div>`).join('');
  renderRecent();
}

function renderRecent(){
  const rows=(state.executions||[]).slice(0,8);
  $('#recentExecutions').innerHTML=rows.length?rows.map(executionRow).join(''):`<div class="panel empty-panel" style="margin:0;max-width:none"><p>No executions yet. Start from New Automation.</p></div>`;
}
function renderExecutions(){ $('#allExecutions').innerHTML=(state.executions||[]).length?(state.executions||[]).map(executionRow).join(''):`<div class="panel empty-panel" style="margin:0;max-width:none"><p>No executions yet.</p></div>`; }
function executionRow(ex){ return `<button class="execution-item" data-execution-id="${ex.id}"><div><div class="execution-title">${escapeHtml(ex.instruction)}</div><div class="execution-meta">${ex.branch||'routing pending'} · ${formatDate(ex.created_at)}</div></div><div><span class="status-pill">${ex.status}</span></div></button>`; }
function escapeHtml(v){ return String(v??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;'); }

function collectPayload(){ return { instruction:$('#instruction').value.trim(), branch:$('#branch').value, topic:$('#topic').value.trim(), chapter:$('#chapter').value.trim(), requestedCount:$('#requestedCount').value?Number($('#requestedCount').value):null, publishToTelegram:$('#publishTelegram').checked, createGoogleDoc:$('#createGoogleDoc').checked, fileIds:state.files.map(f=>f.id) }; }
function renderFiles(){ $('#fileList').innerHTML=state.files.map(f=>`<div class="file-chip"><span>${escapeHtml(f.originalName)}</span><span>${f.kind} · ${(f.sizeBytes/1024/1024).toFixed(2)} MB</span></div>`).join(''); }
function renderRouter(output, low=false){ $('#routerPreview').textContent=JSON.stringify(output,null,2); $('#confidenceFill').style.width=`${Math.round((output.confidence||0)*100)}%`; $('#routeMessage').textContent=low?`Low confidence (${Math.round(output.confidence*100)}%). Choose a branch manually before running.`:`Router confidence: ${Math.round(output.confidence*100)}% · branch: ${output.branch}`; }

async function handleFiles(files){ if(!files.length)return; try{ const data=await api.uploadFiles([...files]); state.files.push(...data.files); renderFiles(); toast(`${data.files.length} file(s) uploaded.`, 'success'); }catch(e){ toast(e.message,'error'); } }

async function handlePreview(){ const payload=collectPayload(); if(!payload.instruction){toast('Enter an instruction first.','error');return;} try{const data=await api.previewRouter(payload); renderRouter(data.output,data.lowConfidence); if(data.lowConfidence) toast('Router confidence is low; choose a branch manually before running.','error');}catch(e){toast(e.message,'error');}}

async function handleRun(event){ event.preventDefault(); const payload=collectPayload(); if(!payload.instruction){toast('Enter an instruction.','error');return;} try{const data=await api.runAutomation(payload); toast(`Execution queued: ${data.executionId}`,'success'); showExecution(data.executionId); refreshExecutions(); }catch(e){toast(e.message,'error');}}

async function showExecution(id){ const drawer=$('#executionDrawer'); drawer.classList.remove('hidden'); $('#drawerTitle').textContent=id; $('#drawerStatus').textContent='Loading…'; $('#drawerSteps').innerHTML=''; $('#drawerLogs').textContent=''; try{ const data=await api.execution(id); renderDrawer(data); subscribeExecution(id); }catch(e){toast(e.message,'error');}}
function renderDrawer(data){ state.selectedExecution=data; $('#drawerStatus').textContent=`${data.status} · ${data.branch||'routing pending'} · ${data.progress||0}%`; $('#drawerProgress').style.width=`${data.progress||0}%`; $('#drawerSteps').innerHTML=(data.steps||[]).map(s=>`<div class="step"><div class="state">${s.status==='completed'?'✓':s.status==='running'?'⏳':s.status==='failed'?'!':'○'}</div><div><div class="name">${escapeHtml(s.action)}</div><div class="meta">${s.service} · ${s.status}${s.error_message?` · ${escapeHtml(s.error_message)}`:''}</div></div><div class="meta">${s.duration_ms?`${s.duration_ms}ms`:''}</div></div>`).join(''); }
function subscribeExecution(id){ if(state.stream)state.stream.close(); const es=new EventSource(`/api/automations/executions/${encodeURIComponent(id)}/events`,{withCredentials:true}); state.stream=es; es.onmessage=()=>refreshDrawer(id); es.addEventListener('execution.progress',()=>refreshDrawer(id)); es.addEventListener('execution.completed',()=>refreshDrawer(id)); es.addEventListener('execution.waiting_review',()=>refreshDrawer(id)); es.addEventListener('execution.failed',()=>refreshDrawer(id)); es.onerror=()=>{}; }
async function refreshDrawer(id){ try{const data=await api.execution(id); renderDrawer(data); if(['completed','failed','cancelled'].includes(data.status)&&state.stream){state.stream.close();state.stream=null;} refreshExecutions(); }catch{} }

$('#loginForm').addEventListener('submit',async e=>{e.preventDefault();try{const data=await api.login({email:$('#loginEmail').value.trim(),password:$('#loginPassword').value,rememberMe:$('#rememberMe').checked});state.user=data.user;setAuthVisible(true);$('#userBadge').textContent=data.user.email;showView('dashboard');await Promise.all([refreshHealth(),refreshExecutions()]);}catch(err){toast(err.message,'error');}});
$('#logoutBtn').addEventListener('click',async()=>{try{await api.logout();}finally{state.user=null;setAuthVisible(false);location.reload();}});
$('#mobileMenu').addEventListener('click',()=>$('#sidebar').classList.toggle('open'));
$('#closeDrawer').addEventListener('click',()=>{$('#executionDrawer').classList.add('hidden'); if(state.stream){state.stream.close();state.stream=null;}});
$('#uploadDrop').addEventListener('click',()=>$('#filesInput').click());
$('#filesInput').addEventListener('change',e=>handleFiles(e.target.files));
$('#previewRoute').addEventListener('click',handlePreview);
$('#automationForm').addEventListener('submit',handleRun);

document.addEventListener('click',e=>{ const viewButton=e.target.closest('[data-view]'); if(viewButton){const view=viewButton.dataset.view; if(viewButton.dataset.branch){$('#branch').value=viewButton.dataset.branch;} showView(view); return;} const row=e.target.closest('[data-execution-id]'); if(row)showExecution(row.dataset.executionId); });

(async function boot(){
  try{ const me=await api.getMe(); state.user=me.user; setAuthVisible(true); $('#userBadge').textContent=me.user.email; showView('dashboard'); await Promise.all([refreshHealth(),refreshExecutions()]); }
  catch{ setAuthVisible(false); $('#loginView').classList.remove('hidden'); $('#pageTitle').textContent='Private dashboard'; $('#pageSubtitle').textContent='Sign in to continue.'; $('#sidebar').classList.add('hidden'); }
})();
