# JEE AI Automation Platform — Phase 1

Private, single-user JEE/education automation control plane. This phase establishes the production-oriented foundation: authentication, SQLite persistence, Redis/BullMQ job infrastructure, secure uploads, AI routing, execution tracking, SSE progress, health checks, and a responsive dashboard.

## Phase 1 boundary

Implemented:
- Private single-user login/session/CSRF protection
- SQLite schema + migration runner
- Redis/BullMQ queue infrastructure
- Background automation-router worker
- Secure PDF/image upload foundation
- Gemini Router integration through `@google/genai` with structured JSON validation
- Mock mode for local development
- Execution/step/event logging and live SSE updates
- Responsive dashboard and New Automation screen
- Health endpoint and dependency status

Not yet implemented as live branch processors: PDF question extraction, Telegram delivery, polls, formula sheets, notes, news, Google Docs/Drive. The dashboard marks these as Phase 2+ rather than pretending they work.

## Requirements

- Node.js 22+
- Redis 7+
- npm 10+

## Setup

```bash
cp .env.example .env
npm install
npm run migrate
npm run seed
```

Set a real `ADMIN_PASSWORD` before production. For local testing, `MOCK_EXTERNAL_SERVICES=true` means the router does not call Gemini/Telegram/Google/search/image providers.

Start the API:

```bash
npm run server
```

Start the worker in another terminal:

```bash
npm run worker
```

Open `http://localhost:3000`.

## Redis

Local Redis:

```bash
redis-server
```

Or connect `REDIS_URL` to a managed/private Redis instance.

## Gemini

For real routing set:

```env
MOCK_EXTERNAL_SERVICES=false
GEMINI_API_KEY=...
GEMINI_MODEL=...
```

`GEMINI_MODEL` is intentionally not hardcoded because model availability changes over time.

## Tests / verification

```bash
npm test
npm run lint
npm run build
```

The project uses Node's built-in test runner. The build/lint scripts perform static validation in addition to unit tests.

## API quick reference

- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/health`
- `GET /api/me`
- `POST /api/files/upload`
- `POST /api/automations/router`
- `POST /api/automations/run`
- `GET /api/executions`
- `GET /api/executions/:id`
- `GET /api/executions/:id/events`

All write endpoints except login require the authenticated session and CSRF header.

## Security notes

- Secrets stay server-side.
- Session cookies are HttpOnly and SameSite=strict; Secure is enabled automatically in production.
- CSRF tokens are bound to the session.
- Uploads are stored outside the public directory and are referenced by internal file IDs.
- MIME type and extension are both validated.
- Upload filenames are not used as storage paths.
- Logs use structured JSON and do not include secrets.
- Uploaded PDFs, OCR text, images, and web content are untrusted data. They are never treated as system instructions.

## Tablet-only GitHub Codespaces

For Android-tablet-only development, see `docs/tablet-codespaces.md`. The included `.devcontainer`
configuration installs Node.js dependencies and Redis in the Codespace and forwards port 3000.
