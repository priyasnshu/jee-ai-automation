#!/usr/bin/env bash
set -euo pipefail
npm run server &
SERVER_PID=$!
npm run worker &
WORKER_PID=$!
cleanup() {
  kill "$SERVER_PID" "$WORKER_PID" 2>/dev/null || true
}
trap cleanup INT TERM EXIT
wait "$SERVER_PID" "$WORKER_PID"
