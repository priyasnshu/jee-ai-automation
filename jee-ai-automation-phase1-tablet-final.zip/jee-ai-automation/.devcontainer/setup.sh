#!/usr/bin/env bash
set -euo pipefail
if ! command -v redis-server >/dev/null 2>&1; then
  sudo apt-get update
  sudo apt-get install -y redis-server
fi
npm install --no-audit --no-fund
if [ ! -f .env ]; then
  cp .env.example .env
  SECRET=$(node -e "console.log(require('node:crypto').randomBytes(32).toString('hex'))")
  sed -i "s#^SESSION_SECRET=.*#SESSION_SECRET=$SECRET#" .env
  sed -i 's#^ADMIN_PASSWORD=.*#ADMIN_PASSWORD=Phase1Test@12345#' .env
  sed -i 's#^MOCK_EXTERNAL_SERVICES=.*#MOCK_EXTERNAL_SERVICES=true#' .env
fi
npm run migrate
npm run seed
