#!/usr/bin/env bash
set -euo pipefail
if redis-cli ping >/dev/null 2>&1; then
  exit 0
fi
redis-server --daemonize yes --bind 127.0.0.1 --port 6379
